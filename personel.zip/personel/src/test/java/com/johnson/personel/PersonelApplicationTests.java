package com.johnson.personel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonelApplicationTests {

	@Test
	void contextLoads() {
	}

}
