package com.johnson.personel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonelApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonelApplication.class, args);
	}

}
