export class EmployeeModelForm{
    eId:number;
    eName:string;
    eSalary:number;
    eType:string;
    eDepartment:string;
    eskill:any[];
}