export class DepartmentModelForm{
    dId:number;
    dName:string;
}