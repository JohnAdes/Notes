export interface IProduct
{
    prodId:Number,
    prodName:String,
    prodPrice:Number;
}