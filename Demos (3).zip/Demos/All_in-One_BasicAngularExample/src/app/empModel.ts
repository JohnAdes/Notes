export class Employee
{
    empId : number;
    empname : String;
    empSalary : number;
}