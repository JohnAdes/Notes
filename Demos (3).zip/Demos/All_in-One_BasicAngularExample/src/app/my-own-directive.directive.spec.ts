import { MyOwnDirectiveDirective } from './my-own-directive.directive';

describe('MyOwnDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MyOwnDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
