import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attributeng-class-ex',
  templateUrl: './attributeng-class-ex.component.html',
  styleUrls: ['./attributeng-class-ex.component.css']
})
export class AttributengClassExComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
