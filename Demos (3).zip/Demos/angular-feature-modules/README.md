# Restructuring an Angular Application with Feature Modules
Check out the relevant [article](https://goo.gl/MzZA9B).
