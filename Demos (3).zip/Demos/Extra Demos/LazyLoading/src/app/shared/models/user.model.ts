export class User {
  name: string = 'Angular';
  age: number = 0;
}