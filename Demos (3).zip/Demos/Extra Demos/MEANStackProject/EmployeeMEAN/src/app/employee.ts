export class Employee {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
   }