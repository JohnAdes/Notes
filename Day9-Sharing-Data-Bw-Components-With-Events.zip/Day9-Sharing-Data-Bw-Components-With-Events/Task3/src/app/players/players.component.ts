import { Component, OnInit } from '@angular/core';
import { Database } from '../common/database';

@Component({
  selector: 'app-players',
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css']
})
export class PlayersComponent implements OnInit {

  private db: Database = new Database();
  public playerData = this.db.teamdetails;
  

  constructor() {
    
  }

  ngOnInit() {

  }

 
}
