import { Component, OnInit } from '@angular/core';
import { Database } from '../common/database';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public sdata:any = [];
  private db:Database = new Database();

  constructor() { 
    this.sdata = JSON.parse(localStorage.getItem("result"));
    console.log("sdata = " + this.sdata);
  }

  ngOnInit() {
  }

}
