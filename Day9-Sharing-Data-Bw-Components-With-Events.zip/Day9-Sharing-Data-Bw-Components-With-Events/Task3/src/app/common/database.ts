export class Database {
  public teamdetails = [
    { 'code': 1, 'team': 'Aston Villa', 'tournament': 'Premier League', 'goals': 29, 'shots': 15.9, 'discipline': 272, 'rating': 7.02 },
    { 'code': 2, 'team': 'Paris Saint-Germain', 'tournament': 'Ligue 1', 'goals': 43, 'shots': 15.5, 'discipline': 365, 'rating': 6.92 },
    { 'code': 3, 'team': 'Juventus', 'tournament': 'Serie A', 'goals': 35, 'shots': 15.9, 'discipline': 335, 'rating': 6.9 },
    { 'code': 4, 'team': 'Atletico Madrid', 'tournament': 'LaLiga', 'goals': 29, 'shots': 11.7, 'discipline': 370, 'rating': 6.87 },
    { 'code': 5, 'team': 'AC Milan', 'tournament': 'Serie A', 'goals': 37, 'shots': 15.6, 'discipline': 441, 'rating': 6.87 },
    { 'code': 6, 'team': 'Manchester City', 'tournament': 'Premier League', 'goals': 24, 'shots': 15.6, 'discipline': 220, 'rating': 6.87 },
    { 'code': 7, 'team': 'Bayern Munich', 'tournament': 'Bundesliga', 'goals': 46, 'shots': 15, 'discipline': 231, 'rating': 6.86 },
    { 'code': 8, 'team': 'Borussia Dortmund', 'tournament': 'Bundesliga', 'goals': 31, 'shots': 15.5, 'discipline': 230, 'rating': 6.86 },
    { 'code': 9, 'team': 'Barcelona', 'tournament': 'LaLiga', 'goals': 37, 'shots': 16.4, 'discipline': 331, 'rating': 6.86 },
    { 'code': 10, 'team': 'Liverpool', 'tournament': 'Premier League', 'goals': 37, 'shots': 15.4, 'discipline': 160, 'rating': 6.84 },
    { 'code': 11, 'team': 'Atalanta', 'tournament': 'Serie A', 'goals': 40, 'shots': 16.9, 'discipline': 330, 'rating': 6.84 },
    { 'code': 12, 'team': 'Lille', 'tournament': 'Ligue 1', 'goals': 33, 'shots': 12.8, 'discipline': 351, 'rating': 6.84 },
    { 'code': 13, 'team': 'Chelsea', 'tournament': 'Premier League', 'goals': 32, 'shots': 13.7, 'discipline': 231, 'rating': 6.83 },
    { 'code': 14, 'team': 'Tottenham', 'tournament': 'Premier League', 'goals': 29, 'shots': 11.3, 'discipline': 211, 'rating': 6.83 },
    { 'code': 15, 'team': 'Real Madrid', 'tournament': 'LaLiga', 'goals': 30, 'shots': 13.6, 'discipline': 320, 'rating': 6.83 },
    { 'code': 16, 'team': 'Lyon', 'tournament': 'Ligue 1', 'goals': 39, 'shots': 16.5, 'discipline': 385, 'rating': 6.83 },
    { 'code': 17, 'team': 'Southampton', 'tournament': 'Premier League', 'goals': 26, 'shots': 10.2, 'discipline': 250, 'rating': 6.82 },
    { 'code': 18, 'team': 'Roma', 'tournament': 'Serie A', 'goals': 37, 'shots': 14.8, 'discipline': 361, 'rating': 6.82 },
    { 'code': 19, 'team': 'Napoli', 'tournament': 'Serie A', 'goals': 34, 'shots': 19, 'discipline': 272, 'rating': 6.82 },
    { 'code': 20, 'team': 'Everton', 'tournament': 'Premier League', 'goals': 26, 'shots': 10.9, 'discipline': 282, 'rating': 7.02 },
  ];

  public maxData: any = {};

  constructor() { 
    this.initializeApp();
  }



  initializeApp() {
    //console.log(Math.max.apply(Math, this.playerData.map(function(o) { return o.shots; })));

    this.maxData = {

      'Matches': Math.max.apply(Math, this.teamdetails.map(function (o) { return o.code; })),

      'shots': Math.max.apply(Math, this.teamdetails.map(function (o) { return o.shots; })),

      'Goals': Math.max.apply(Math, this.teamdetails.map(function (o) { return o.goals; })),

      'rating': Math.max.apply(Math, this.teamdetails.map(function (o) { return o.rating; }))

    };

    console.log(this.maxData);
    localStorage.setItem("result", JSON.stringify(this.maxData));
  }

}
