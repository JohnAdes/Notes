import { Database } from './database';

describe('Database', () => {
  it('should create an instance', () => {
    expect(new Database()).toBeTruthy();
  });
});
