package com.johnson.empinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
