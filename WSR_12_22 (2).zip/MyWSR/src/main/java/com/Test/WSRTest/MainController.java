package com.Test.WSRTest;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.thymeleaf.util.DateUtils;

@Controller
public class MainController {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public String enteredUser = "";
	public boolean userFound = false;
	public boolean validPass = false;
	public String empRole = "";
	public Date selectedWorkWeek;
	
	List<Report> reports = new ArrayList<Report>();
	List<User> users = new ArrayList<User>();
	List<Report> personalReport = new ArrayList<Report>();
	List<Project> projects = new ArrayList<Project>();
	List<Report> repWeekFilter = new ArrayList<Report>();
	List<Task> tasks = new ArrayList<Task>();
	
	WorkDate woD = new WorkDate();
	
	User selEmp = new User();
	List<Project> persProj = new ArrayList<Project>();
	
	//List that holds the dates of Monday - Friday for selected week
	//List<WorkDate> datesInRange = new ArrayList<WorkDate>();
	//List<String> datesInRangeS = new ArrayList<String>();
	
	CurrentUser currentUser = new CurrentUser();
	
	ListSize listSize = new ListSize();
	
	int reportIt = 0;
	int userIt = 0;
	
	
	@GetMapping("/login")
	public String showLoginForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "login_form";
	}
	
	@PostMapping("/login")
	public String submitLoginForm(@ModelAttribute("user") User user) {
		
		initializeTables();
		
		
		
		
		//Validate Login info
				String query2 = "SELECT * FROM account";
				List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query2);
				
				
				accounts.forEach( rowMap -> {
					if (user.getEmp_username().equals((String)rowMap.get("emp_username"))) {
						userFound = true;
						if (user.getPassword().equals((String)rowMap.get("password"))) {
							validPass = true;
							empRole = (String)rowMap.get("emp_role");
							enteredUser = user.getEmp_username();
						}
					}
				});
		
		//Valid login
		if (userFound == true && validPass == true) {
			
			//Supervisor Page
			if (empRole.equals("S")) {
				return "supHome";
			}
			
			else {
				return "empHome";
			}
		}
		
		//Invalid Password
		else if (userFound == true && validPass == false) {
			userFound = false;
			return "invalidPass";
		}
		
		else {
			userFound = false;
			validPass = false;
			return "invalidUser";
		}
		
	}
	
	@GetMapping("/empHome")
	public String empHomePage(Model model) {
		model.addAttribute("empName", "Testing");
		return "empHome";
	}
	
	@GetMapping("/register")
	public String showRegForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "register_form";
	}
	
	@PostMapping("/register")
	public String submitRegForm(@ModelAttribute("user") User user) {
		
		//INSERT new user into database
		String sql = "INSERT INTO account (first_name, last_name, emp_role, email, emp_username, password) VALUES (?, ?, ?, ?, ?, ?)";
		int result = jdbcTemplate.update(sql, user.getFirst_name(), user.getLast_name(), user.getEmp_role(), user.getEmail(), user.getEmp_username(), user.getPassword());
	
		if (result > 0) {
			System.out.println("A new row has been inserted");
		}
		
		
		//SELECT accounts from database (check that user has been added)
				String query = "SELECT * FROM account";
				List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query);
				
				System.out.println();
				System.out.println();
				
				accounts.forEach( rowMap -> {
					String first_name = (String)rowMap.get("first_name");
					String last_name = (String)rowMap.get("last_name");
					String emp_role = (String)rowMap.get("emp_role");
					String email = (String)rowMap.get("email");
					String emp_username = (String)rowMap.get("emp_username");
					String password = (String)rowMap.get("password");
					
					System.out.println("first_name" + " - " + first_name + " - " + "last_name" + " - " + last_name + " - "+"emp_role" + " - " + emp_role + " - " +"email" + " - " + email + " - " + "emp_username" + " - " + emp_username + " - " + "password" + " - " + password);
				});
		return "register_success";
	}
	
	@GetMapping("/createReport")
	public String showRepForm(Model model) {
		Report report = new Report();
		model.addAttribute("report", report);
		WorkDate workDate = new WorkDate();
		model.addAttribute("workDate", workDate);
		
	    int mondayPlus;
	    Calendar cd = Calendar.getInstance();
	             // Get today is the day of the week, Sunday is the first day, and Tuesday is the second day...
	             int dayOfWeek = cd.get(Calendar.DAY_OF_WEEK)-1; // Since Chinese Monday is the first day, we subtract 1 here
	    if (dayOfWeek == 1) {
	        mondayPlus = 0;
	    } else {
	        mondayPlus = 1 - dayOfWeek;
	    }
	    GregorianCalendar currentDate = new GregorianCalendar();
	    currentDate.add(GregorianCalendar.DATE, mondayPlus);
	    java.util.Date monday = currentDate.getTime();
	    java.sql.Date sqlMonday = new java.sql.Date(monday.getTime());
	    System.out.println("CURRENT MONDAY: " + sqlMonday);
	    
	
		currentUser.setUsername(enteredUser);
		currentUser.setWorkWeek(sqlMonday);
		model.addAttribute("currentUser", currentUser);
		model.addAttribute("projects", projects);

		
		return "createReport";
	}
	
	@PostMapping("/createReport")
	public String submitRepForm(@ModelAttribute("report") Report report) {

		//First Row
		if(report.getTask_name1() != null && !report.getTask_name1().isEmpty()) {
				
				Report newRep = new Report();
				newRep.setWork_week(currentUser.getWorkWeek());
				newRep.setReport_date(currentUser.getReportDate());
				newRep.setEmp_username(currentUser.getUsername());
				
				newRep.setProj_name(report.getProj_name1());
				newRep.setTask_name(report.getTask_name1());
				newRep.setTask_status(report.getTask_status1());
				newRep.setDue_date(java.sql.Date.valueOf(report.getDue_date1()));
				newRep.setHours_worked(report.getHours_worked1());
				
				//INSERT new report into database
				String sql = "INSERT INTO report (work_week, report_date, emp_username, proj_name, task_name, task_status, due_date, hours_worked) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				int result = jdbcTemplate.update(sql, currentUser.getWorkWeek(), currentUser.getReportDate(), currentUser.getUsername(), newRep.getProj_name(), newRep.getTask_name(), newRep.getTask_status(), newRep.getDue_date(), newRep.getHours_worked());
			
				if (result > 0) {
					System.out.println("A new row has been inserted");
				}
			
		}
		

		//Second Row
		if(report.getTask_name2() != null && !report.getTask_name2().isEmpty()) {
				
				Report newRep = new Report();
				newRep.setWork_week(currentUser.getWorkWeek());
				newRep.setReport_date(currentUser.getReportDate());
				newRep.setEmp_username(currentUser.getUsername());
				
				newRep.setProj_name(report.getProj_name2());
				newRep.setTask_name(report.getTask_name2());
				newRep.setTask_status(report.getTask_status2());
				newRep.setDue_date(java.sql.Date.valueOf(report.getDue_date2()));
				newRep.setHours_worked(report.getHours_worked2());
				
				//INSERT new report into database
				String sql = "INSERT INTO report (work_week, report_date, emp_username, proj_name, task_name, task_status, due_date, hours_worked) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				int result = jdbcTemplate.update(sql, currentUser.getWorkWeek(), currentUser.getReportDate(), currentUser.getUsername(), newRep.getProj_name(), newRep.getTask_name(), newRep.getTask_status(), newRep.getDue_date(), newRep.getHours_worked());
			
				if (result > 0) {
					System.out.println("A new row has been inserted");
				}
			
		}
		
		//Third Row
		if(report.getTask_name3() != null && !report.getTask_name3().isEmpty()) {
				
				Report newRep = new Report();
				newRep.setWork_week(currentUser.getWorkWeek());
				newRep.setReport_date(currentUser.getReportDate());
				newRep.setEmp_username(currentUser.getUsername());
				
				newRep.setProj_name(report.getProj_name3());
				newRep.setTask_name(report.getTask_name3());
				newRep.setTask_status(report.getTask_status3());
				newRep.setDue_date(java.sql.Date.valueOf(report.getDue_date3()));
				newRep.setHours_worked(report.getHours_worked3());
				
				//INSERT new report into database
				String sql = "INSERT INTO report (work_week, report_date, emp_username, proj_name, task_name, task_status, due_date, hours_worked) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				int result = jdbcTemplate.update(sql, currentUser.getWorkWeek(), currentUser.getReportDate(), currentUser.getUsername(), newRep.getProj_name(), newRep.getTask_name(), newRep.getTask_status(), newRep.getDue_date(), newRep.getHours_worked());
			
				if (result > 0) {
					System.out.println("A new row has been inserted");
				}
			
		}
		
		//Fourth Row
		if(report.getTask_name4() != null && !report.getTask_name4().isEmpty()) {
				
				Report newRep = new Report();
				newRep.setWork_week(currentUser.getWorkWeek());
				newRep.setReport_date(currentUser.getReportDate());
				newRep.setEmp_username(currentUser.getUsername());
				
				newRep.setProj_name(report.getProj_name4());
				newRep.setTask_name(report.getTask_name4());
				newRep.setTask_status(report.getTask_status4());
				newRep.setDue_date(java.sql.Date.valueOf(report.getDue_date4()));
				newRep.setHours_worked(report.getHours_worked4());
				
				//INSERT new report into database
				String sql = "INSERT INTO report (work_week, report_date, emp_username, proj_name, task_name, task_status, due_date, hours_worked) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				int result = jdbcTemplate.update(sql, currentUser.getWorkWeek(), currentUser.getReportDate(), currentUser.getUsername(), newRep.getProj_name(), newRep.getTask_name(), newRep.getTask_status(), newRep.getDue_date(), newRep.getHours_worked());
			
				if (result > 0) {
					System.out.println("A new row has been inserted");
				}
			
		}
		
		//Fifth Row
		if(report.getTask_name5() != null && !report.getTask_name5().isEmpty()) {
				
				Report newRep = new Report();
				newRep.setWork_week(currentUser.getWorkWeek());
				newRep.setReport_date(currentUser.getReportDate());
				newRep.setEmp_username(currentUser.getUsername());
				
				newRep.setProj_name(report.getProj_name5());
				newRep.setTask_name(report.getTask_name5());
				newRep.setTask_status(report.getTask_status5());
				newRep.setDue_date(java.sql.Date.valueOf(report.getDue_date5()));
				newRep.setHours_worked(report.getHours_worked5());
				
				//INSERT new report into database
				String sql = "INSERT INTO report (work_week, report_date, emp_username, proj_name, task_name, task_status, due_date, hours_worked) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				int result = jdbcTemplate.update(sql, currentUser.getWorkWeek(), currentUser.getReportDate(), currentUser.getUsername(), newRep.getProj_name(), newRep.getTask_name(), newRep.getTask_status(), newRep.getDue_date(), newRep.getHours_worked());
			
				if (result > 0) {
					System.out.println("A new row has been inserted");
				}
			
		}
		

		
		return "empHome";
	}
	
	@GetMapping("/createProject")
	public String newProjForm(Model model) {
		Project project = new Project();
		model.addAttribute("project", project);
		

		model.addAttribute("employees", users);

		
		return "createProject";
	}
	
	@PostMapping("/createProject")
	public String submitProjForm(@ModelAttribute("project") Project project) {
		
		
		Project newProject = new Project();
		newProject.setProj_name(project.getProj_name());
		newProject.setStart_date(project.getStart_date());
		newProject.setEnd_date(project.getEnd_date());
		newProject.setClient_name(project.getClient_name());
		newProject.setProj_goal(project.getProj_goal());
		newProject.setEmp_assigned(project.getEmp_assigned());
		
		projects.add(newProject);
		
		String sql = "INSERT INTO project (proj_name, start_date, end_date, client_name, proj_goal) VALUES (?, ?, ?, ?, ?)";
		int result = jdbcTemplate.update(sql, newProject.getProj_name(), newProject.getStart_date(), newProject.getEnd_date(), newProject.getClient_name(), newProject.getProj_goal());
	
		if (result > 0) {
			System.out.println("A new row has been inserted");
		}
		
		
		List<String> empHolder = new ArrayList<String>();
		empHolder = newProject.getEmp_assigned();
		for (int i = 0; i < empHolder.size(); i++) {
			String sql2 = "INSERT INTO project_emp_assigned (emp_assigned, proj_name) VALUES (?, ?)";
			int result2 = jdbcTemplate.update(sql2, empHolder.get(i), newProject.getProj_name());
			
			if (result2 > 0) {
				System.out.println("A new row has been inserted");
			}
		}
		

		System.out.println("TESTING NEW PROJECT");
		System.out.println(newProject.getProj_name() + newProject.getStart_date() + newProject.getEnd_date() + newProject.getClient_name() + newProject.getProj_goal());
		System.out.println(newProject.getEmp_assigned());
		
		return "supHome";
	}
	
	
	
	@GetMapping("/selectWeek")
	public String selectWeekForm(Model model) {

		return "viewReportsEmp";
	}
	
	@PostMapping("/selectWeek")
	public String submitWeekSel(@ModelAttribute("workDate") WorkDate workDate) {
		
		System.out.println();
		System.out.println();
		System.out.println("Selected Work Week: " + workDate.getWork_week());
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		
		selectedWorkWeek = workDate.getWork_week();
		
		if (selectedWorkWeek.equals(Date.valueOf("1111-11-11"))) {
			System.out.println("ALL SELECTED");
		}
		
		else {
			Date startDate = selectedWorkWeek;
			Date endDate = selectedWorkWeek;
			
			Calendar startC = Calendar.getInstance();
			startC.setTime(startDate);
			
			Calendar endC = Calendar.getInstance();
			endC.setTime(endDate);
			endC.add(Calendar.DATE, 5);
			Date newDateEnd = new Date(endC.getTimeInMillis());
			java.sql.Date newDateEndS = newDateEnd;

			List<Date> dR = new ArrayList<Date>();

			while (startDate.before(newDateEndS)) {
				
				dR.add(startDate);

				startC.add(Calendar.DATE, 1);
				
				Date testDate = new Date(startC.getTimeInMillis());
				java.sql.Date newDate = testDate;
				
				startDate = newDate;
			}
			
			woD.setDate_range(dR);
			
			System.out.println("RANGE OF DATES: ");
			for (int i = 0; i < dR.size(); i++) {
				System.out.println(dR.get(i));
				
				//Filter personal reports by week's date range
				for (int j=0; j < personalReport.size(); j++) {
					System.out.println(personalReport.get(i).getWork_week());
				}
				
			}
			
			System.out.println("WORK WEEKS");
			for (int j=0; j < personalReport.size(); j++) {
				System.out.println(personalReport.get(j).getWork_week());
				
				
				if (workDate.getWork_week().equals(personalReport.get(j).getWork_week())) {
					repWeekFilter.add(personalReport.get(j));
				}
			}
			
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println("Filtered Reports by Week: ");
			for (int i=0; i < repWeekFilter.size(); i++) {
				System.out.println(repWeekFilter.get(i).getWork_week());
				System.out.println(repWeekFilter.get(i).getReport_date());
				System.out.println(repWeekFilter.get(i).getTask_status());
			}
			System.out.println();
			System.out.println();
			System.out.println();
			
		}

		System.out.println("TEST MAPPING");
		return "selectDay";
	}
	
	@GetMapping("/selectDay")
	public String getDaySel(Model model) {
		model.addAttribute("workDate", woD);
		System.out.println("TESTTESTTEST");
		return "selectDay";
	}
	
	@PostMapping("/selectDay")
	public String submitDaySel(@ModelAttribute("workDate") WorkDate workDate) {
		
		
		System.out.println("SELECTED WORK DATE: " + workDate.getSelected_date());
		
		
		return "viewReports";
	}
	
	@GetMapping("/addTask")
	public String addTaskForm(Model model) {

		model.addAttribute("projects", projects);

		return "addTask";
	}
	
	@GetMapping("/viewReportsEmp")
	public String showRepsForm(Model model) {
		String query2 = "SELECT * FROM report WHERE emp_username='" + enteredUser + "'";
		List<Map<String, Object>> rep = jdbcTemplate.queryForList(query2);
		
		rep.forEach( rowMap -> {
			Date work_week = (Date)rowMap.get("work_week");
			Date report_date = (Date)rowMap.get("report_date");
			String emp_username = (String)rowMap.get("emp_username");
			String proj_name = (String)rowMap.get("proj_name");
			String task_name = (String)rowMap.get("task_name");
			String task_status = (String)rowMap.get("task_status");
			Date due_date = (Date)rowMap.get("due_date");
			int hours_worked = (int)rowMap.get("hours_worked");

			
			Report addReport = new Report();
			addReport.setWork_week(work_week);
			addReport.setReport_date(report_date);
			addReport.setEmp_username(emp_username);
			addReport.setProj_name(proj_name);
			addReport.setTask_name(task_name);
			addReport.setTask_status(task_status);
			addReport.setDue_date(due_date);
			addReport.setHours_worked(hours_worked);
			
			personalReport.add(addReport);
		});

		WorkDate workDate = new WorkDate();
		model.addAttribute("workDate", workDate);
		
	    int mondayPlus;
	    Calendar cd = Calendar.getInstance();
	             // Get today is the day of the week, Sunday is the first day, and Tuesday is the second day...
	             int dayOfWeek = cd.get(Calendar.DAY_OF_WEEK)-1; // Since Chinese Monday is the first day, we subtract 1 here
	    if (dayOfWeek == 1) {
	        mondayPlus = 0;
	    } else {
	        mondayPlus = 1 - dayOfWeek;
	    }
	    GregorianCalendar currentDate = new GregorianCalendar();
	    currentDate.add(GregorianCalendar.DATE, mondayPlus);
	    java.util.Date monday = currentDate.getTime();
	    java.sql.Date sqlMonday = new java.sql.Date(monday.getTime());
	    System.out.println("CURRENT MONDAY: " + sqlMonday);
	    
	
		currentUser.setUsername(enteredUser);
		currentUser.setWorkWeek(sqlMonday);
		model.addAttribute("currentUser", currentUser);
		model.addAttribute("projects", projects);
		
		model.addAttribute("persRep", personalReport);
		return "viewReportsEmp";
	}
	
	@PostMapping("/viewReportsEmp")
	public String returnEmpHome(@ModelAttribute("report") Report report) {
		
		return "empHome";
	}
	
	@GetMapping("/viewEmployees")
	public String showEmps(Model model) {
		model.addAttribute("users", users);
		model.addAttribute("usersSize", listSize);
		
		System.out.println("TEST MAPPING VIEWEMP");
		return "viewEmployees";
	}
	
	@PostMapping("/viewEmployees")
	public String submitEmpSel(@ModelAttribute("selectedEmp") User selEmp, @RequestParam(value="viewEmp", required=true) String viewEmp) {
		
		System.out.println("EMPLOYEE SELECTED");
		System.out.println(viewEmp);
		
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i).getEmp_username().equals(viewEmp)) {
				selEmp = users.get(i);
			}
		}
		
		return "empInformation";
	}
	
	@GetMapping("/empInformation")
	public String showEmpInfo(Model model) {
		
		//persProj
		System.out.println("TESTING SELECT EMP");
		
		
		model.addAttribute("selEmp", selEmp);
		
		return "empInformation";
	}
	
	//@PostMapping("/empInformation")

	
	
	@GetMapping("/viewProjects")
	public String showProjForm(Model model) {

		model.addAttribute("projects", projects);
		
		
		return "viewProjects";
	}
	
	@GetMapping("/myAccount")
	public String myAccount(Model model) {
		System.out.println("MY ACCOUNT TEST");
		System.out.println(currentUser.getUsername());
		System.out.println(enteredUser);
		
		User selAccount = new User();
		
		String query1 = "SELECT * FROM account";
		List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query1);
		
		
		accounts.forEach( rowMap -> {
			
			String first_name = (String)rowMap.get("first_name");
			String last_name = (String)rowMap.get("last_name");
			String emp_role = (String)rowMap.get("emp_role");
			String email = (String)rowMap.get("email");
			String emp_username = (String)rowMap.get("emp_username");
			String password = (String)rowMap.get("password");
			
			if (emp_username.equals(enteredUser)) {
				selAccount.setFirst_name(first_name);
				selAccount.setLast_name(last_name);
				selAccount.setEmp_role(emp_role);
				selAccount.setEmail(email);
				selAccount.setEmp_username(emp_username);
				selAccount.setPassword(password);
			}
		});
		
		System.out.println(selAccount.getFirst_name());
		System.out.println(selAccount.getLast_name());
		
		model.addAttribute("selAccount", selAccount);
		
		return "myAccount";
	}
	
	@GetMapping("/changePass")
	public String changePass(Model model) {
		System.out.println("CHANGE PASS TEST");
		System.out.println(currentUser.getUsername());
		System.out.println(enteredUser);
		
		User selAccount = new User();
		
		String query1 = "SELECT * FROM account";
		List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query1);
		
		
		accounts.forEach( rowMap -> {
			
			String first_name = (String)rowMap.get("first_name");
			String last_name = (String)rowMap.get("last_name");
			String emp_role = (String)rowMap.get("emp_role");
			String email = (String)rowMap.get("email");
			String emp_username = (String)rowMap.get("emp_username");
			String password = (String)rowMap.get("password");
			
			if (emp_username.equals(enteredUser)) {
				selAccount.setFirst_name(first_name);
				selAccount.setLast_name(last_name);
				selAccount.setEmp_role(emp_role);
				selAccount.setEmail(email);
				selAccount.setEmp_username(emp_username);
				selAccount.setPassword(password);
			}
		});
		
		System.out.println(selAccount.getFirst_name());
		System.out.println(selAccount.getLast_name());
		System.out.println("Current Pass: " + selAccount.getPassword());
		
		model.addAttribute("selAccount", selAccount);
		
		return "changePass";
	}
	
	@PostMapping("/changePass")
	public String changePassForm(@ModelAttribute("selAccount") User selAccount) {
		System.out.println("Changed Password: ");
		System.out.println(selAccount.getPassword());
		
		System.out.println("Current User");
		System.out.println(enteredUser);
		
		//Change password in database
		Connection con = null;
	      PreparedStatement ps = null;
	      
	      try {
	    	  con = DriverManager.getConnection("jdbc:mysql:///wsr_schema", "root", "password");
	         String query = "UPDATE account SET password=? where emp_username=? ";
	         ps = con.prepareStatement(query);
	         ps.setString(1, selAccount.getPassword());
	         ps.setString(2, enteredUser);
	         ps.executeUpdate();
	         System.out.println("Record is updated successfully......");
	         } catch (Exception e) {
	            e.printStackTrace();
	      }
		
		
		//When password change is complete logout user for them to sign in with new pass
		//Clear lists
		reports.clear();
		users.clear();
		personalReport.clear();
		projects.clear();
		
		//Reset account info
		enteredUser = "";
		userFound = false;
		validPass = false;
		empRole = "";
		
		//Return to login form
		return "index";
		
	}
	
	@GetMapping("/logout")
	public String logout(Model model) {
		
		//Clear lists
		reports.clear();
		users.clear();
		personalReport.clear();
		projects.clear();
		
		//Reset account info
		enteredUser = "";
		userFound = false;
		validPass = false;
		empRole = "";
		
		//Return to login form
		return "index";
	}
	
	@GetMapping("/visual")
	public String visual(Model model) {
		
		return "visual";
	}
	
	
	public void initializeTables() {
		
		//Initialize Users Array
		String query1 = "SELECT * FROM account";
		List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query1);
		
		
		accounts.forEach( rowMap -> {
			
			String first_name = (String)rowMap.get("first_name");
			String last_name = (String)rowMap.get("last_name");
			String emp_role = (String)rowMap.get("emp_role");
			String email = (String)rowMap.get("email");
			String emp_username = (String)rowMap.get("emp_username");
			String password = (String)rowMap.get("password");
			
			User addUser = new User();
			addUser.setFirst_name(first_name);
			addUser.setLast_name(last_name);
			addUser.setEmp_role(emp_role);
			addUser.setEmail(email);
			addUser.setEmp_username(emp_username);
			addUser.setPassword(password);
			
			users.add(addUser);
			userIt++;
		});
		
		listSize.setUserSize(users.size());
		
		//Initialize Reports Array
				String query2 = "SELECT * FROM report";
				List<Map<String, Object>> rep = jdbcTemplate.queryForList(query2);
				
				rep.forEach( rowMap -> {
					Date work_week = (Date)rowMap.get("work_week");
					Date report_date = (Date)rowMap.get("report_date");
					String emp_username = (String)rowMap.get("emp_username");
					String proj_name = (String)rowMap.get("proj_name");
					String task_name = (String)rowMap.get("task_name");
					String task_status = (String)rowMap.get("task_status");
					Date due_date = (Date)rowMap.get("due_date");
					int hours_worked = (int)rowMap.get("hours_worked");

					
					Report addReport = new Report();
					addReport.setWork_week(work_week);
					addReport.setReport_date(report_date);
					addReport.setEmp_username(emp_username);
					addReport.setProj_name(proj_name);
					addReport.setTask_name(task_name);
					addReport.setTask_status(task_status);
					addReport.setDue_date(due_date);
					addReport.setHours_worked(hours_worked);
					
					reports.add(addReport);
					reportIt++;
				});
				
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println("TEST ACCOUNT ARRAY");
				System.out.println("Size: " + users.size());
				
				for (int i = 0; i < users.size(); i++) {

						System.out.println(users.get(i).getFirst_name() + " " + users.get(i).getLast_name() + " " + users.get(i).getEmp_role());

				}
				System.out.println();
				System.out.println();
				System.out.println();
				
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println("TEST REPORT ARRAY");
				for (int i = 0; i < reports.size(); i++) {
					System.out.println(reports.get(i).getEmp_username() + " " + reports.get(i).getTask_name());
				}
				System.out.println();
				System.out.println();
				System.out.println();
				
				
				//Initialize Projects
				String query3 = "SELECT * FROM project";
				List<Map<String, Object>> rep2 = jdbcTemplate.queryForList(query3);
				
				rep2.forEach( rowMap -> {
					String proj_name = (String)rowMap.get("proj_name");
					Date start_date = (Date)rowMap.get("start_date");
					Date end_date = (Date)rowMap.get("end_date");
					String client_name = (String)rowMap.get("client_name");
					String proj_goal = (String)rowMap.get("proj_goal");
					

					Project addProject = new Project();
					addProject.setProj_name(proj_name);
					addProject.setStart_date(start_date);
					addProject.setEnd_date(end_date);
					addProject.setClient_name(client_name);
					addProject.setProj_goal(proj_goal);
					
					projects.add(addProject);
				});
				
				for (int i=0; i < projects.size(); i++) {
					List<String> empHolder = new ArrayList<String>();
					String proj_n_holder = projects.get(i).getProj_name();
					
					String query4 = "SELECT * FROM project_emp_assigned";
					List<Map<String, Object>> rep3 = jdbcTemplate.queryForList(query4);
					rep3.forEach( rowMap -> {
						String proj_name_holder = (String)rowMap.get("proj_name");
						
						if (proj_name_holder.equals(proj_n_holder)) {
							String emp_name_holder = (String)rowMap.get("emp_assigned");
							empHolder.add(emp_name_holder);
						}
					});
					
					projects.get(i).setEmp_assigned(empHolder);
				}
				
				//Initialize Tasks
				String query4 = "SELECT proj_name, task_name FROM wsr_schema.report GROUP BY task_name ORDER BY proj_name";
				List<Map<String, Object>> rep3 = jdbcTemplate.queryForList(query4);
				
				rep3.forEach( rowMap -> {
					String proj_name = (String)rowMap.get("proj_name");
					String task_name = (String)rowMap.get("task_name");
					
					Task addTask = new Task();
					addTask.setProj_name(proj_name);
					addTask.setTask_name(task_name);
				
					
					tasks.add(addTask);
				});
				
				//System.out.println("TESTING TASK INITIAL");
				//for (int i=0; i < tasks.size(); i++) {
				//	System.out.println("Proj Name: " + tasks.get(i).getProj_name() + "    Task Name: " + tasks.get(i).getTask_name());
				//}
	}
	
}
