package com.Test.WSRTest;

import java.sql.Date;

public class Report {
	private Date work_week;
	private Date report_date;
	private String emp_username;
	private String proj_name;
	private String task_name;
	private String task_status;
	private Date due_date;
	private int hours_worked;
	
	private String proj_name1;
	private String proj_name2;
	private String proj_name3;
	private String proj_name4;
	private String proj_name5;
	private String task_name1;
	private String task_name2;
	private String task_name3;
	private String task_name4;
	private String task_name5;
	private String task_status1;
	private String task_status2;
	private String task_status3;
	private String task_status4;
	private String task_status5;
	private String due_date1;
	private String due_date2;
	private String due_date3;
	private String due_date4;
	private String due_date5;
	private int hours_worked1;
	private int hours_worked2;
	private int hours_worked3;
	private int hours_worked4;
	private int hours_worked5;
	
	
	public Date getWork_week() {
		return work_week;
	}
	public void setWork_week(Date work_week) {
		this.work_week = work_week;
	}
	public Date getReport_date() {
		return report_date;
	}
	public void setReport_date(Date report_date) {
		this.report_date = report_date;
	}
	public String getEmp_username() {
		return emp_username;
	}
	public void setEmp_username(String emp_username) {
		this.emp_username = emp_username;
	}
	public String getProj_name() {
		return proj_name;
	}
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	public String getTask_name() {
		return task_name;
	}
	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}
	public String getTask_status() {
		return task_status;
	}
	public void setTask_status(String task_status) {
		this.task_status = task_status;
	}
	public Date getDue_date() {
		return due_date;
	}
	public void setDue_date(Date due_date) {
		this.due_date = due_date;
	}
	public int getHours_worked() {
		return hours_worked;
	}
	public void setHours_worked(int hours_worked) {
		this.hours_worked = hours_worked;
	}
	public String getProj_name1() {
		return proj_name1;
	}
	public void setProj_name1(String proj_name1) {
		this.proj_name1 = proj_name1;
	}
	public String getProj_name2() {
		return proj_name2;
	}
	public void setProj_name2(String proj_name2) {
		this.proj_name2 = proj_name2;
	}
	public String getProj_name3() {
		return proj_name3;
	}
	public void setProj_name3(String proj_name3) {
		this.proj_name3 = proj_name3;
	}
	public String getProj_name4() {
		return proj_name4;
	}
	public void setProj_name4(String proj_name4) {
		this.proj_name4 = proj_name4;
	}
	public String getProj_name5() {
		return proj_name5;
	}
	public void setProj_name5(String proj_name5) {
		this.proj_name5 = proj_name5;
	}
	public String getTask_name1() {
		return task_name1;
	}
	public void setTask_name1(String task_name1) {
		this.task_name1 = task_name1;
	}
	public String getTask_name2() {
		return task_name2;
	}
	public void setTask_name2(String task_name2) {
		this.task_name2 = task_name2;
	}
	public String getTask_name3() {
		return task_name3;
	}
	public void setTask_name3(String task_name3) {
		this.task_name3 = task_name3;
	}
	public String getTask_name4() {
		return task_name4;
	}
	public void setTask_name4(String task_name4) {
		this.task_name4 = task_name4;
	}
	public String getTask_name5() {
		return task_name5;
	}
	public void setTask_name5(String task_name5) {
		this.task_name5 = task_name5;
	}
	public String getTask_status1() {
		return task_status1;
	}
	public void setTask_status1(String task_status1) {
		this.task_status1 = task_status1;
	}
	public String getTask_status2() {
		return task_status2;
	}
	public void setTask_status2(String task_status2) {
		this.task_status2 = task_status2;
	}
	public String getTask_status3() {
		return task_status3;
	}
	public void setTask_status3(String task_status3) {
		this.task_status3 = task_status3;
	}
	public String getTask_status4() {
		return task_status4;
	}
	public void setTask_status4(String task_status4) {
		this.task_status4 = task_status4;
	}
	public String getTask_status5() {
		return task_status5;
	}
	public void setTask_status5(String task_status5) {
		this.task_status5 = task_status5;
	}

	
	public String getDue_date1() {
		return due_date1;
	}
	public void setDue_date1(String due_date1) {
		this.due_date1 = due_date1;
	}
	public String getDue_date2() {
		return due_date2;
	}
	public void setDue_date2(String due_date2) {
		this.due_date2 = due_date2;
	}
	public String getDue_date3() {
		return due_date3;
	}
	public void setDue_date3(String due_date3) {
		this.due_date3 = due_date3;
	}
	public String getDue_date4() {
		return due_date4;
	}
	public void setDue_date4(String due_date4) {
		this.due_date4 = due_date4;
	}
	public String getDue_date5() {
		return due_date5;
	}
	public void setDue_date5(String due_date5) {
		this.due_date5 = due_date5;
	}
	public int getHours_worked1() {
		return hours_worked1;
	}
	public void setHours_worked1(int hours_worked1) {
		this.hours_worked1 = hours_worked1;
	}
	public int getHours_worked2() {
		return hours_worked2;
	}
	public void setHours_worked2(int hours_worked2) {
		this.hours_worked2 = hours_worked2;
	}
	public int getHours_worked3() {
		return hours_worked3;
	}
	public void setHours_worked3(int hours_worked3) {
		this.hours_worked3 = hours_worked3;
	}
	public int getHours_worked4() {
		return hours_worked4;
	}
	public void setHours_worked4(int hours_worked4) {
		this.hours_worked4 = hours_worked4;
	}
	public int getHours_worked5() {
		return hours_worked5;
	}
	public void setHours_worked5(int hours_worked5) {
		this.hours_worked5 = hours_worked5;
	}

	
	
}
