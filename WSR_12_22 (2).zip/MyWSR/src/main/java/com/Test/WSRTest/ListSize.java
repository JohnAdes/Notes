package com.Test.WSRTest;

public class ListSize {

	private int userSize;
	private int reportSize;
	public int getUserSize() {
		return userSize;
	}
	public void setUserSize(int userSize) {
		this.userSize = userSize;
	}
	public int getReportSize() {
		return reportSize;
	}
	public void setReportSize(int reportSize) {
		this.reportSize = reportSize;
	}
	
	
}
