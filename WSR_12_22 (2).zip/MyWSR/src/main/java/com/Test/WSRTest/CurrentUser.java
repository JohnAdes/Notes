package com.Test.WSRTest;

import java.sql.Date;

public class CurrentUser {
	
	long millis = System.currentTimeMillis();
	java.sql.Date date = new java.sql.Date(millis);

	private String username;
	private Date workWeek;
	private Date reportDate = date;
	private int totalHours;
	
	
	

	public int getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(int totalHours) {
		this.totalHours = totalHours;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Date getWorkWeek() {
		return workWeek;
	}

	public void setWorkWeek(Date workWeek) {
		this.workWeek = workWeek;
	}

	public Date getReportDate() {
		return reportDate;
	}

	public void setReportDate() {
		this.reportDate = date;
	}
	
	

}
