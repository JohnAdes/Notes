package com.Test.WSRTest;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Project {
	private String proj_name;
	private Date start_date;
	private Date end_date;
	private String client_name;
	private String proj_goal;
	private List<String> emp_assigned = new ArrayList<String>();
	
	
	
	public List<String> getEmp_assigned() {
		return emp_assigned;
	}
	public void setEmp_assigned(List<String> emp_assigned) {
		this.emp_assigned = emp_assigned;
	}
	public String getProj_name() {
		return proj_name;
	}
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public String getClient_name() {
		return client_name;
	}
	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}
	public String getProj_goal() {
		return proj_goal;
	}
	public void setProj_goal(String proj_goal) {
		this.proj_goal = proj_goal;
	}
	
	
}
