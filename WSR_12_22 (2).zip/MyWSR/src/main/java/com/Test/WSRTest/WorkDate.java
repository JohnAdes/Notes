package com.Test.WSRTest;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class WorkDate {

	private Date work_week;
	private Date report_date;
	private Date monday_date;
	private Date tuesday_date;
	private Date wednesday_date;
	private Date thursday_date;
	private Date friday_date;
	private String selected_day;
	private boolean allFlag;
	private Date selected_date;
	private Date date_holder;
	private List<Date> date_range = new ArrayList<Date>();
	
	
	public List<Date> getDate_range() {
		return date_range;
	}
	public void setDate_range(List<Date> date_range) {
		this.date_range = date_range;
	}
	public Date getDate_holder() {
		return date_holder;
	}
	public void setDate_holder(Date date_holder) {
		this.date_holder = date_holder;
	}
	public Date getSelected_date() {
		return selected_date;
	}
	public void setSelected_date(Date selected_date) {
		this.selected_date = selected_date;
	}
	public String getSelected_day() {
		return selected_day;
	}
	public void setSelected_day(String selected_day) {
		this.selected_day = selected_day;
	}
	public Date getWork_week() {
		return work_week;
	}
	public void setWork_week(Date work_week) {
		this.work_week = work_week;
	}
	public Date getReport_date() {
		return report_date;
	}
	public void setReport_date(Date report_date) {
		this.report_date = report_date;
	}
	public Date getMonday_date() {
		return monday_date;
	}
	public void setMonday_date(Date monday_date) {
		this.monday_date = monday_date;
	}
	public Date getTuesday_date() {
		return tuesday_date;
	}
	public void setTuesday_date(Date tuesday_date) {
		this.tuesday_date = tuesday_date;
	}
	public Date getWednesday_date() {
		return wednesday_date;
	}
	public void setWednesday_date(Date wednesday_date) {
		this.wednesday_date = wednesday_date;
	}
	public Date getThursday_date() {
		return thursday_date;
	}
	public void setThursday_date(Date thursday_date) {
		this.thursday_date = thursday_date;
	}
	public Date getFriday_date() {
		return friday_date;
	}
	public void setFriday_date(Date friday_date) {
		this.friday_date = friday_date;
	}
	public boolean isAllFlag() {
		return allFlag;
	}
	public void setAllFlag(boolean allFlag) {
		this.allFlag = allFlag;
	}
	
	
}
