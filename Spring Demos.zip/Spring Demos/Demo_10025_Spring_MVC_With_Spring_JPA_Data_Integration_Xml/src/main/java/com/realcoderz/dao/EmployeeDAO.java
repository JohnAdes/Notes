package com.realcoderz.dao;

import org.springframework.data.repository.CrudRepository;

import com.realcoderz.entity.EmployeeEntity;

public interface EmployeeDAO extends CrudRepository<EmployeeEntity,Integer >{


}