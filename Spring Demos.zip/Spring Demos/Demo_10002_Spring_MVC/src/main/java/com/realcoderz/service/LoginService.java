package com.realcoderz.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.realcoderz.business.bean.LoginBean;
import com.realcoderz.dao.LoginDAO;

@Service
public class LoginService {

	@Autowired
	private LoginDAO loginDAO;

		public String validateLogin(LoginBean loginBean){
			
			return loginDAO.validateLogin(loginBean);
			
		}
	
	
}
