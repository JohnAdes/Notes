package com.realcoderz.web.controller;

import org.springframework.web.servlet.ModelAndView;

import com.realcoderz.business.bean.CustomerBean;

//proper annotation
public class CustomerController {
	
	//Default method is Get
	//map to page "/loadCustomerRegistrationPage")
	public ModelAndView showRegistrationPage() {
		//"Registration", "customerBean",	new CustomerBean()
		return null;
	}

	// "/registration", default request submission method is post
	//@ModelAttribute("customerBean") to read 
	public ModelAndView register(CustomerBean customerBean) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("RegistrationSuccess");
		modelAndView.addObject("message", "Welcome: " + customerBean.getCustomerName());
		return modelAndView;
	}
}