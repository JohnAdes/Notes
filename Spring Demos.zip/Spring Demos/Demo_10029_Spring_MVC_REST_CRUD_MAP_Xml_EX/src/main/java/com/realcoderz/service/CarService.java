package com.realcoderz.service;

import java.util.Collection;

import com.realcoderz.bussiness.bean.CarBean;

public interface CarService {

	Collection<CarBean> getAllCar();

	CarBean getCarDetailsById(int id);

	Integer addCar(CarBean car);

	CarBean updateCar(CarBean car);

	CarBean removeCar(int id);

}