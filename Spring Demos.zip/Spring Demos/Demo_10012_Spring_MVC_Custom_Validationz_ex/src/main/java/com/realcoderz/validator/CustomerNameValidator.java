package com.realcoderz.validator;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CustomerNameValidator implements _________<_____________, String>{//name of the related annotation

	
	// write the code to check if name has @ 
	// then return true else return false
}
