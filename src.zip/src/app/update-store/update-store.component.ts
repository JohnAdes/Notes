import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '../store';
import { StoreService } from '../store.service';

@Component({
  selector: 'app-update-store',
  templateUrl: './update-store.component.html',
  styleUrls: ['./update-store.component.css']
})
export class UpdateStoreComponent implements OnInit {

  
  id!: number;
  store: Store = new Store();
  goToStoreList: any;
  constructor(private storeService: StoreService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.storeService.getStoreById(this.id).subscribe(data => {
      this.store = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.storeService.updateStore(this.id, this.store).subscribe( data =>{
      this.goToStoreList();
    }
    , error => console.log(error));
  }

}
