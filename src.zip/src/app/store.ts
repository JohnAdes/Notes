export class Store {
    id!: number;
    name!: string;
    city!: string;
    state!: string;
}
