import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../product';
import { Store } from '../store';
import { StoreService } from '../store.service';

@Component({
  selector: 'app-store-details',
  templateUrl: './store-details.component.html',
  styleUrls: ['./store-details.component.css']
})
export class StoreDetailsComponent implements OnInit {

  id!: number;
  store!: Store;
  
  product!: Product;

  constructor(private route: ActivatedRoute, private storeService: StoreService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.store = new Store();
    this.storeService.getStoreById(this.id).subscribe( data => {
      this.store = data;
    })
  }

}
