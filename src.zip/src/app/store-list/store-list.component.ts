
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Store} from '../store'
import { StoreService } from '../store.service';

@Component({
  selector: 'app-store-list',
  templateUrl: './store-list.component.html',
  styleUrls: ['./store-list.component.css']
})
export class StoreListComponent implements OnInit {

  stores!: Store[];

   // Pagination parameters.
   p: number = 1;
   count: number = 5;
  // page: any;
  // tableSize: any;
 
  constructor(private storeService : StoreService,
    private router: Router) { }

  ngOnInit(): void {
    this.getStores();
  }

  private getStores(){
    this.storeService.getStoresList().subscribe(data => {
      this.stores = data;
    });
  }

  storeDetails(id: number){
    this.router.navigate(['store-details', id]);
  }

  updateStore(id: number){
    this.router.navigate(['update-store', id]);
  }

  deleteStore(id: number){
    this.storeService.deleteStore(id).subscribe( data => {
      console.log(data);
      this.getStores();
    })
  }

}
