import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from './store';


@Injectable({
  providedIn: 'root'
})
export class StoreService {

  
  private baseURL = "http://localhost:8096/api/v1/stores";

  constructor(private httpClient : HttpClient) { }

  getStoresList(): Observable<Store[]>{
    return this.httpClient.get<Store[]>(`${this.baseURL}`);
  }
  createStore(store: Store): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, store);
  }

  getStoreById(id: number): Observable<Store>{
    return this.httpClient.get<Store>(`${this.baseURL}/${id}`);
  }

  updateStore(id: number, store: Store): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, store);
  }

  deleteStore(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
}
}
