import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '../store';
import { StoreService } from '../store.service';

@Component({
  selector: 'app-create-store',
  templateUrl: './create-store.component.html',
  styleUrls: ['./create-store.component.css']
})
export class CreateStoreComponent implements OnInit {

  store: Store = new Store();
  constructor(private storeService: StoreService,
    private router: Router) { }


  ngOnInit(): void {
  }

  saveStore(){
    this.storeService.createStore(this.store).subscribe( data =>{
      console.log(data);
      this.goToStoreList();
    },
    error => console.log(error));
  }

  goToStoreList(){
    this.router.navigate(['/stores']);
  }

  onSubmit(){
    console.log(this.store);
    this.saveStore();
  }
 

}
