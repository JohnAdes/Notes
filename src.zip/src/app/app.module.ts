import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule } from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { CreateProductComponent } from './create-product/create-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { FormsModule } from '@angular/forms';
// import { CreateStoreComponent } from './create-store/create-store.component';
// import { UpdateStoreComponent } from './update-store/update-store.component';
// import { StoreListComponent } from './store-list/store-list.component';
// import { StoreDetailsComponent } from './store-details/store-details.component';

@NgModule({
  declarations: [
    AppComponent,
    // StoreListComponent,
    // StoreDetailsComponent,
    // CreateStoreComponent,
    // UpdateStoreComponent,
    ProductListComponent,
    ProductDetailsComponent,
    CreateProductComponent,
    UpdateProductComponent
  ],
  imports: [
    BrowserModule,
    NgxPaginationModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  exports: [
    NgxPaginationModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
