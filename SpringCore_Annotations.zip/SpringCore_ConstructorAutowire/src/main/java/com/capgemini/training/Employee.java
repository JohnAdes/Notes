package com.capgemini.training;

public class Employee {
private int employeeId;
private String employeeName;
private double salary;
private Address address;


public Employee(Address address) {
	System.out.println("Employee Constructor :Address Object is Injected to the Employee");
	this.address = address;
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	System.out.println("From Setter of Employee Address.......");
	this.address = address;
}
public void display()
{
	System.out.println("\n Employee Details are");
	System.out.println("Employee Id"+this.getEmployeeId());
	System.out.println("Employee Name"+this.getEmployeeName());
	System.out.println("Employee Salary"+this.getSalary());
	System.out.println("\n Address Line1"+this.getAddress().getAddressLine1());
	System.out.println("\n Address Line2"+this.getAddress().getAddressLine2());
}

}
