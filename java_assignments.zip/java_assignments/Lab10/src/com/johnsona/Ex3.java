package com.johnsona;

import java.util.function.Predicate;

@FunctionalInterface
interface Validate <String, Boolean>{
     boolean apply(String username, String password);
}

public class Ex3 {


    public static void main(String[] args) {
        Validate usernameAndPassword =((username, password) -> (boolean) username);
    }
}
