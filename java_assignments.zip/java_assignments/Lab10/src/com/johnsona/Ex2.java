package com.johnsona;


@FunctionalInterface
interface FormatFunctionalInterface{
    public int twoNumbers(int x, int y);
}

public class Ex2 {
}
