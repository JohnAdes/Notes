package com.johnsona;


@FunctionalInterface
interface MyFunctionalInterface{
    public int twoNumbers(int x, int y);
}

public class Ex1 {

    public static void main(String[] args) {
         MyFunctionalInterface num =((x, y) -> (int) Math.pow(x, y));
        System.out.println(num.twoNumbers(2,3));
    }

}
