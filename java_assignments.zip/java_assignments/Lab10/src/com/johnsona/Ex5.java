package com.johnsona;

public class Ex5 {
}
