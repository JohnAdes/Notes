package com.johnson;

import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EmployeeRepository {

    private static List<Employee> employeeList;
    static {
        createEmployeeList();
    }

    public static List<Employee> getEmployeeList() {
        return employeeList;
    }

    public static void setEmployeeList(List<Employee> employeeList) {
        EmployeeRepository.employeeList = employeeList;
    }

    private static void createEmployeeList(){
        employeeList = new ArrayList<>();
        employeeList.add(new Employee(1001,"Mike", "James", "jMike@mail.com", (LocalDate.of(2020, 11, 30)), "234-876-1234", "Developer", 40000.00, 3001, (new Department(102,"Treasury",null) )));
        employeeList.add(new Employee(1121,"Mike", "Lee", "jMike1@mail.com", (LocalDate.of(2010,2,15)), "234-846-1233", "Analyst", 32000.00, 3001, (new Department(104,"Risk",null) )));
        employeeList.add(new Employee(1022,"Boderick", "Daniel", "jMike4@mail.com", (LocalDate.of(2021,4,1)), "234-856-1244", "Agile Coach", 50000.00, 3001, (new Department(101,"Operations",null) )));
        employeeList.add(new Employee(1231,"Will", "Matt", "jMike10@mail.com", (LocalDate.of(2015,11,30)), "234-476-1123", "Ux Designer", 6000.00, 3001, (new Department(203,"Sales",null) )));
        employeeList.add(new Employee(1451,"Acher", "Rock", "jMike2@mail.com", (LocalDate.of(2019,12,30)), "234-2276=-1844", "Developer", 38000.00, 3001, (new Department(102,"Treasury",null) )));

    }
}
