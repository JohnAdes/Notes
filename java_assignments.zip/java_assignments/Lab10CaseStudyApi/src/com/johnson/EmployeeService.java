package com.johnson;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import java.util.List;
import java.util.Map;


public class EmployeeService {

    private static EmployeeRepository employeeRepository;

    public static void main(String[] args) {
        countEmployeesPerDept();
        findMostSenior();
        deptWithHighestEmployee();
        sumOfAllSalary();
        sortedEmployee();

    }


    private static void println()
    {
        System.out.println("===============================================================================================");
    }

    public static void findMostSenior(){

        System.out.println("listing the most senior employee");
        println();
        Comparator<Employee> employeeHireDateComparator = Comparator.comparing(Employee::getHireDate);
        Employee mostSeniorEmployee = Collections.min(EmployeeRepository.getEmployeeList(), Comparator.comparing(Employee::getHireDate));
        System.out.println("The Most Senior Employee: " + mostSeniorEmployee);

    }

    public static void countEmployeesPerDept(){
        System.out.println("Employee Count per Department");
        println();
        Map<String, List<Employee>> departmentCount = EmployeeRepository.getEmployeeList().stream().collect(Collectors.groupingBy((worker) -> worker.getDepartment().getDepartmentName()));
        for (String department : departmentCount.keySet()) {
            System.out.println(department + ":" + departmentCount.get(department).size());
        }
    }

        public static void sumOfAllSalary(){
            System.out.println();
            System.out.println("Summation of all Employee salaries");
            println();
            Double totalSalary = EmployeeRepository.getEmployeeList().stream().map(employee -> employee.getSalary()).collect(Collectors.summingDouble(Double::doubleValue));
                System.out.println("Total Salary of all employees is: " + totalSalary);

            }

        public static void deptWithHighestEmployee(){
            System.out.println();
            System.out.println("Department with Highest Employee");
            println();
            Long departmentCount = EmployeeRepository.getEmployeeList().stream().collect(Collectors.groupingBy((worker) -> worker.getDepartment().getDepartmentName(), Collectors.counting())).values().stream().max(Comparator.comparing(a->a)).get();
                System.out.println(departmentCount);
        }
        public static void sortedEmployee(){
        //Compare by employee id, department id and then first name

            List<Employee> employeeList = EmployeeRepository.getEmployeeList();

            Comparator<Employee> empIdComp = (emp1, emp2) -> emp1.getEmployeeId().compareTo(emp2.getEmployeeId());
            Comparator<Employee> deptIdComp = (emp1, emp2) -> emp1.getDepartment().getDepartmentId().compareTo(emp2.getDepartment().getDepartmentId());
            Comparator<Employee> empNameComp = (emp1, emp2) -> emp1.getFirstName().compareTo(emp2.getFirstName());

            Comparator<Employee> compareEmployee;
            compareEmployee = empIdComp
                            .thenComparing(deptIdComp)
                            .thenComparing(empNameComp);

            List<Employee> sortedEmployees = EmployeeRepository.getEmployeeList().stream()
                .sorted(compareEmployee)
                .collect(Collectors.toList());

        System.out.println("sorted Employees");
        for (Employee employee : employeeList){
            System.out.println(employee);
        }
        }
    }


