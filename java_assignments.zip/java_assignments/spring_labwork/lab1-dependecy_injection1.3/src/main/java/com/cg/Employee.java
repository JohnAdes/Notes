package com.cg;

public class Employee {

    private int employeeId;
    private String employeeName;
    private double salary;
//    private SBU sbu_details;
    private int age;


    public Employee(int employeeId, String employeeName, double salary, int age) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.salary = salary;
        this.age = age;
    }

    public Employee() {

    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

//    public SBU getSbu_details() {
//        return sbu_details;
//    }
//
//    public void setSbu_details(SBU sbu_details) {
//        this.sbu_details = sbu_details;
//    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void display() {
        System.out.println("\n Employee Details");
        System.out.println("\n----------------------------");
        System.out.println(toString());


    }

    @Override
    public String toString() {
        return "Employee{" +
                "age=" + age +
                ", employeeId=" + employeeId +
                ", employeeName='" + employeeName + '\'' +
                ", salary=" + salary +

                '}';
    }
}
