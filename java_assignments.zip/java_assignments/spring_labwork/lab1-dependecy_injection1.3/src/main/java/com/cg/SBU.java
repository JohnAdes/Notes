package com.cg;

import java.util.List;

public class SBU {
    private int sbuId;
    private String sbuName;
    private String sbuHead;
    private List<Employee> empList;

    public int getSbuId() {
        return sbuId;
    }

    public void setSbuId(int sbuId) {
        this.sbuId = sbuId;
    }

    public String getSbuName() {
        return sbuName;
    }

    public void setSbuName(String sbuName) {
        this.sbuName = sbuName;
    }

    public String getSbuHead() {
        return sbuHead;
    }

    public void setSbuHead(String sbuHead) {
        this.sbuHead = sbuHead;
    }

    public List<Employee> getEmpList() {
        return empList;
    }

    public void setEmpList(List<Employee> empList) {
        this.empList = empList;
    }

    public void display() {

        System.out.println("\nSBU Details");
        System.out.print("SBU Id : "+this.getSbuId());
        System.out.print (", SBU Name : "+this.getSbuName());
        System.out.print (", SBU Head : "+this.getSbuHead());
        System.out.println("\nEmployee Details");
//        System.out.println("\n----------------------------");
        System.out.println(toString());


    }

    @Override
    public String toString() {
        return "" +
                 empList +
                "";
    }
}
