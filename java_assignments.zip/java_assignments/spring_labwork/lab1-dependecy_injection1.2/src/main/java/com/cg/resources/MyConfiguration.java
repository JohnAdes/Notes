package com.cg.resources;

import com.cg.Employee;
import com.cg.SBU;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
        public class MyConfiguration {
        @Bean(name="employeeSp")
        public Employee createEmployee()
        {
        Employee employee=new Employee();
        employee.setEmployeeId(12345);
        employee.setEmployeeName("Harriet");
        employee.setSalary(40000.00);
        SBU sbu = createSBU();
        employee.setSbu_details(sbu);
        employee.setAge(40);
        return employee;
        }
        @Bean(name="sbu")
        public SBU createSBU()
        {
        SBU sbu=new SBU();
        sbu.setSbuId(123);
        sbu.setSbuName("Product Engineering Services");
        sbu.setSbuHead("Kiran Rao");
        return sbu;
        }
        }