package com.cg.resources;

import com.cg.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
        public class MyConfiguration {
        @Bean(name="employeeSp")
        public Employee createEmployee()
        {
        Employee employee=new Employee();
        employee.setEmployeeId(12345);
        employee.setEmployeeName("Harriet");
        employee.setSalary(40000.00);
        employee.setBusinessUnit("PES-BU");
        employee.setAge(30);
        return employee;
        }

}