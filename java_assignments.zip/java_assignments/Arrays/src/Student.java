import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Student {
//    String name;
//    int marks[];
//    float total, average;
//
//    void accept() {
//        try {
//            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//            System.out.println("Enter the name of Student");
//            name = br.readLine();
//            System.out.println("Enter the number of Subject");
//            int n = Integer.parseInt(br.readLine());
//            marks = new int[n];
//            for (int i = 0; i < marks.length; i++) {
//                System.out.println("Enter marks in Subject" + (i + 1) + ":");
//                marks[i] = Integer.parseInt(br.readLine());
//                total += marks[i];
//            }
//            average = total / marks.length;
//        } catch (IOException e) {
//
//        }
//    }
//    void display()
//    {
//        System.out.println("Student Name"+name);
//        for(int i=0;i<marks.length;i++)
//        {
//            System.out.println("Marks in Subject"+(i+1)+" are\t"+marks[i]);
//        }
//        System.out.println("Total = "+total);
//        System.out.println("Average = "+average);
//    }
//}

    String name;
    int marks[][]=new int[3][5];
    float total[]=new float[3];
    float average[]=new float[3];



    void accept()
    {
        try
        {
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter the name of the Student");
            name =br.readLine();

            // System.out.println("Enter the number of Subjects");
// int n=Integer.parseInt(br.readLine());
// marks=new int[n];
            for(int i=0;i<marks.length;i++) {
                System.out.println("Enter marks of Semester" + (i + 1) + ":");
                for (int j = 0; j < marks[i].length; j++) {
                    System.out.println("Enter marks in Subjects" + (j + 1) + ":");
                    marks[i][j] = Integer.parseInt(br.readLine());
                    total[i] += marks[i][j];
                }
                average[i] = total[i] / marks[i].length;


            }
        }catch(IOException e)
        {

        }
    }
    void display()
    {
        System.out.println("Student Name"+name);
        for(int i=0;i<marks.length;i++)
        {
            System.out.println("Marks of Semester Subject"+(i+1)+"are\t");
            for(int j=0;j<marks[i].length;j++)
            {
                System.out.println("Subjects are"+(j+1+":"));
                System.out.println(marks[i][j]);
            }
            System.out.println("Total"+total[i]);
            System.out.println("Average"+average[i]);
        }

    }
}

class TestStudent
{
    public static void main(String[] args) {
        Student s=new Student();
        s.accept();
        s.display();
    }
}
