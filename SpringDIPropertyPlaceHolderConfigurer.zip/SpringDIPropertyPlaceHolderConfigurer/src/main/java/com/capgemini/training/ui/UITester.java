package com.capgemini.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.capgemini.training.Employee;
import com.capgemini.training.resources.MyConfiguration;

public class UITester {
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(MyConfiguration.class);
	Employee emp=(Employee)context.getBean("employee");
    System.out.println(emp);
}
}
