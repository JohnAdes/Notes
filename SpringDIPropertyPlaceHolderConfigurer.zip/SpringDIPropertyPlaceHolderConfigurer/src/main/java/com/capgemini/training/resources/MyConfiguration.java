package com.capgemini.training.resources;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(ReaderConfiguration.class)
@ComponentScan(basePackages="com.capgemini.training")
public class MyConfiguration
{
	
}