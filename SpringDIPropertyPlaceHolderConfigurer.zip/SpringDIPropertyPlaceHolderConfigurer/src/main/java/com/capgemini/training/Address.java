package com.capgemini.training;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class Address {
	@Value("RRNagar")
private String addressLine1;
	@Value("India")
private String addressLine2;
public Address() {
	System.out.println("From the constructor of Address Class");
}
public String getAddressLine1() {
	return addressLine1;
}
public void setAddressLine1(String addressLine1) {
	System.out.println("From the setter of Address Line1");
	this.addressLine1 = addressLine1;
}
public String getAddressLine2() {
	return addressLine2;
}
public void setAddressLine2(String addressLine2) {
	System.out.println("From the setter of Address Line2");
	this.addressLine2 = addressLine2;
}
@Override
public String toString() {
	return "Address [addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + "]";
}

}
