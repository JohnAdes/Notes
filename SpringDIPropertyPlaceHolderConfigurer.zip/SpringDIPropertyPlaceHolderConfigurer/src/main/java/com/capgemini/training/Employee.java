package com.capgemini.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	@Autowired
	private Address address;
	@Value("${EmployeeId}")
	private Integer employeeId;
	@Value("${Salary}")
	private Double salary;
	@Value("${EmployeeName}")
	private String employeeName;
	@Value("${TestProp}")
	private String test;
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		System.out.println("From Setter of Employee Address ");
		this.address = address;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void display()
	{
		System.out.println("\n Employee Details");
		System.out.println("Employee Id"+this.getEmployeeId());
		System.out.println("Employee Name"+this.getEmployeeName());
		System.out.println("Employee Salary"+this.getSalary());
		System.out.println("Employee Address Line1"+this.getAddress().getAddressLine1());
		System.out.println("Employee Address Line2"+this.getAddress().getAddressLine2());

	}
	@Override
	public String toString() {
		return "Employee [address=" + address + ", employeeId=" + employeeId + ", salary=" + salary + ", employeeName="
				+ employeeName + "]";
	}

}
