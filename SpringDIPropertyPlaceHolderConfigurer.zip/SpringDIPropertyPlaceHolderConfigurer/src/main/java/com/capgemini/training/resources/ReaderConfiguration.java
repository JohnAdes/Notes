package com.capgemini.training.resources;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@PropertySource({"classpath:properties/config.properties","classpath:properties/naveen_config.properties"})
public class ReaderConfiguration {
	
	public PropertySourcesPlaceholderConfigurer preopertyConfigureIn()
	{
		return new PropertySourcesPlaceholderConfigurer();
	}

}
