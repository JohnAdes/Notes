package com.johnson.cgdiner.service;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.models.Store;
import com.johnson.cgdiner.repo.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepo productRepo;

    @Override
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    public List<Product> getProductListByStore(Store store){
        return productRepo.findByStore(store);
    };

   public  List<Product> findByStoreAndName(Store store, String name){
       return productRepo.findByStoreAndName(store, name);
   }

    @Override
    public void saveProduct(Product product) {
        this.productRepo.save(product);
    }

    @Override
    public Product getProductById(long id) {
        Optional<Product> optional = productRepo.findById(id);
        Product product = null;
        if (optional.isPresent()){
            product = optional.get();
        } else {
            throw new RuntimeException("Product not found for id :: " + id);
        }
        return product;
    }

    @Override
    public void deleteProductById(long id) {
        this.productRepo.deleteById(id);
    }

    @Override
    public Page<Product> findPagination(int pageNo, int pageSize, String sortField, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name())
                ? Sort.by(sortField).ascending() : Sort.by(sortField).descending();

        Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
        return this.productRepo.findAll(pageable);
    }

}
