package com.johnson.cgdiner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgdinerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgdinerApplication.class, args);
	}

}
