package com.johnson.cgdiner.models;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "stores")
public class Store {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String city;
    private String state;

    @Lob
    @Type(type="org.hibernate.type.BinaryType")
    private byte[] store_logo;

    @ManyToMany(mappedBy = "store", cascade = CascadeType.ALL)
    private List<Product> products;

    public Store() {
    }

    public byte[] getStore_logo() {
        return store_logo;
    }

    public void setStore_logo(byte[] store_logo) {
        this.store_logo = store_logo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

}
