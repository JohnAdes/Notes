package com.johnson.cgdiner.repo;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.models.Store;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreRepo extends JpaRepository<Store, Long> {

}
