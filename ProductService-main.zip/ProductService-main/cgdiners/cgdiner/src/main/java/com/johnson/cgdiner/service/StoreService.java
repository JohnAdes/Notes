package com.johnson.cgdiner.service;

import com.johnson.cgdiner.models.Store;
import org.springframework.data.domain.Page;

import java.util.List;

public interface StoreService {
    List<Store> getAllStores();
    void saveStore(Store Store);
    Store getStoreById(long id);
    void deleteStoreById(long id);
    Page<Store> findPagination(int pageNo, int pageSize, String sortField, String sortDirection);
}
