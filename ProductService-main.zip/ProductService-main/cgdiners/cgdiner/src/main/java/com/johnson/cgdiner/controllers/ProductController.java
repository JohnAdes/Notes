package com.johnson.cgdiner.controllers;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.models.Store;
import com.johnson.cgdiner.service.ProductService;
import com.johnson.cgdiner.service.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private StoreService storeService;

//    @GetMapping("/")
//    public String viewHomePage(Model model){
//        return "home";
//    }

    @GetMapping("/store/{id}")
    public String viewStoreProducts(@PathVariable (value = "id") long id, Model model){
        Store store = storeService.getStoreById(id);
        List<Product> productList = productService.getProductListByStore(store);
        model.addAttribute("store", store );
//        findPagination(1, "name", "asc", model);
        model.addAttribute("productList", productList );
        return "/store/viewStoreProducts";
    }
//
//    @GetMapping("/page/{pageNo}")
//    public String findPagination(@PathVariable (value = "pageNo") int pageNo,
//                                 @RequestParam("sortField") String sortField,
//                                 @RequestParam("sortDirection") String sortDirection,
//                                 Model model){
//        int pageSize = 5;
//
//        Page<Product> page = productService.findPagination(pageNo, pageSize, sortField, sortDirection);
//        List<Product> productList = page.getContent();
//
//        model.addAttribute("currentPage", pageNo);
//        model.addAttribute("totalPages", page.getTotalPages());
//        model.addAttribute("totalItems", page.getTotalElements());
//
//        model.addAttribute("sortField", sortField);
//        model.addAttribute("sortDirection", sortDirection);
//        model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc":"asc");
//
//        model.addAttribute("productList", productList);
//        return "/store/viewStoreProducts";

    @GetMapping("/store/newProduct/{id}")
    public String addStoreProduct(@PathVariable (value = "id") long id, Model model){
        Store store = storeService.getStoreById(id);
        Product product = new Product();
        product.setStore(store);
        model.addAttribute("store", store );
        model.addAttribute("product", product );
        return "/store/newProduct";
    }

//    // Display list of products
//    @GetMapping("/products")
//    public String viewProductPage(Model model){
//       findPagination(1, "name", "asc", model);
//        return "showProduct";
//    }

//    @GetMapping("store/newProduct")
//    public String addProductForm(Model model){
//        Product product = new Product();
//        model.addAttribute("product", product );
//        return "newProduct";
//    }
    @PostMapping("store/save")
    public String saveProduct(@ModelAttribute("product")  Product product){
        productService.saveProduct(product);
        Long sId = product.getStore().getId();
        return "redirect:/store/" + sId;

    }

    @GetMapping("/edit/{id}")
    public String editProductForm(@PathVariable (value = "id") long id, Model model){
        Product product = productService.getProductById(id);
        model.addAttribute("product", product );
        return "updateProduct";
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable (value = "id") long id, Product product){
        this.productService.deleteProductById(id);
        Long sId = product.getStore().getId();
        return "redirect:/store/" + sId;
    }

}
