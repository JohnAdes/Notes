package com.johnson.cgdiner.controllers;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.service.ProductService;
import com.johnson.cgdiner.service.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private ProductService productService;

    @Autowired
    private StoreService storeService;

    @GetMapping("/")
    public String viewHomePage(Model model){
        return "home";
    }

//    // Display list of products
//    @GetMapping("/products")
//    public String viewProductPage(Model model){
//       findPagination(1, "name", "asc", model);
//        return "showProduct";
//    }
//
//    @GetMapping("/newProduct")
//    public String addProductForm(Model model){
//        Product product = new Product();
//        model.addAttribute("product", product );
//        return "newProduct";
//    }
//    @PostMapping("/save")
//    public String saveProduct(@ModelAttribute("product")  Product product){
//        productService.saveProduct(product);
//        return "redirect:/products";
//
//    }
//
//    @GetMapping("/edit/{id}")
//    public String editProductForm(@PathVariable (value = "id") long id, Model model){
//        Product product = productService.getProductById(id);
//        model.addAttribute("product", product );
//        return "updateProduct";
//    }
//
//    @GetMapping("/delete/{id}")
//    public String deleteProduct(@PathVariable (value = "id") long id){
//        this.productService.deleteProductById(id);
//        return "redirect:/products";
//    }
//
//    @GetMapping("/store/{id}")
//    public String viewStoreProductsForm(@PathVariable (value = "id") long id, Model model){
//        Product product = productService.getProductById(id);
//        model.addAttribute("product", product );
//        return "updateProduct";
//    }
//
//    @GetMapping("/page/{pageNo}")
//    public String findPagination(@PathVariable (value = "pageNo") int pageNo,
//                                 @RequestParam("sortField") String sortField,
//                                 @RequestParam("sortDirection") String sortDirection,
//                                 Model model){
//        int pageSize = 5;
//
//        Page<Product> page = productService.findPagination(pageNo, pageSize, sortField, sortDirection);
//        List<Product> productList = page.getContent();
//
//        model.addAttribute("currentPage", pageNo);
//        model.addAttribute("totalPages", page.getTotalPages());
//        model.addAttribute("totalItems", page.getTotalElements());
//
//        model.addAttribute("sortField", sortField);
//        model.addAttribute("sortDirection", sortDirection);
//        model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc":"asc");
//
//        model.addAttribute("productList", productList);
//        return "showProduct";
//
//    }
}
