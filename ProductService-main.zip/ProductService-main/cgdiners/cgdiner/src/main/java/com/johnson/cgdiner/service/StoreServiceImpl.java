package com.johnson.cgdiner.service;

import com.johnson.cgdiner.models.Store;
import com.johnson.cgdiner.repo.StoreRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StoreServiceImpl implements StoreService {

    @Autowired
    private StoreRepo storeRepo;

    @Override
    public List<Store> getAllStores() {
        return storeRepo.findAll();
    }

    @Override
    public void saveStore(Store store) {
        this.storeRepo.save(store);
    }

    @Override
    public Store getStoreById(long id) {
        Optional<Store> optional = storeRepo.findById(id);
        Store store = null;
        if (optional.isPresent()){
            store = optional.get();
        } else {
            throw new RuntimeException("Store not found for id :: " + id);
        }
        return store;
    }

    @Override
    public void deleteStoreById(long id) {
        this.storeRepo.deleteById(id);
    }

    @Override
    public Page<Store> findPagination(int pageNo, int pageSize, String sortField, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name())
                ? Sort.by(sortField).ascending() : Sort.by(sortField).descending();

        Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
        return this.storeRepo.findAll(pageable);
    }

}
