package com.johnson.cgdiner.controllers;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.models.Store;
import com.johnson.cgdiner.service.ProductService;
import com.johnson.cgdiner.service.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class StoreController {

    @Autowired
    private StoreService storeService;

//    @GetMapping("/")
//    public String viewHomePage(Model model){
//        return "home";
//    }

    // Display list of stores
    @GetMapping("/stores")
    public String viewStorePage(Model model){
       findPagination(1, "name", "asc", model);
        return "/store/showStores";
    }

    @GetMapping("/newStore")
    public String addStoreForm(Model model){
        Store store = new Store();
        model.addAttribute("store", store );
        return "newStore";
    }
    @PostMapping("/saveStore")
    public String saveStore(@ModelAttribute("store")  Store store){
        storeService.saveStore(store);
        return "redirect:/stores";

    }

    @GetMapping("/store/edit/{id}")
    public String editStoreForm(@PathVariable (value = "id") long id, Model model){
        Store store = storeService.getStoreById(id);
        model.addAttribute("store", store );
        return "updateStore";

    }

    @GetMapping("/store/delete/{id}")
    public String deleteStore(@PathVariable (value = "id") long id){
        this.storeService.deleteStoreById(id);
        return "redirect:/stores";

    }

    @GetMapping("/store/page/{pageNo}")
    public String findPagination(@PathVariable (value = "pageNo") int pageNo,
                                 @RequestParam("sortField") String sortField,
                                 @RequestParam("sortDirection") String sortDirection,
                                 Model model){
        int pageSize = 5;

        Page<Store> page = storeService.findPagination(pageNo, pageSize, sortField, sortDirection);
        List<Store> storeList = page.getContent();

        model.addAttribute("currentPage", pageNo);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());

        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDirection", sortDirection);
        model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc":"asc");

        model.addAttribute("storeList", storeList);
        return "/store/showStores";

    }
}
