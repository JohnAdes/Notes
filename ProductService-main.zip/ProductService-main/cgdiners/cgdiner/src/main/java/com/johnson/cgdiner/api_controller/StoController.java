package com.johnson.cgdiner.api_controller;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.models.Store;
import com.johnson.cgdiner.repo.ProductRepo;
import com.johnson.cgdiner.repo.StoreRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/stores")
public class StoController {


    @Autowired
    private StoreRepo storeRepo;

    @GetMapping
    public List<Store> list(){
        return storeRepo.findAll();
    }

    @GetMapping
    @RequestMapping("{id")
    public Store get(@PathVariable Long id) {
        return storeRepo.getById(id);
    }

    @PostMapping
    public Store create(@RequestBody final Store store){
        return  storeRepo.saveAndFlush(store);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    public void delete(@PathVariable Long id){
        storeRepo.deleteById(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    public Store update(@PathVariable Long id, @RequestBody Store store){
      Store existingStore = storeRepo.getById(id);
        BeanUtils.copyProperties(store, existingStore, "store_id");
        return storeRepo.saveAndFlush(existingStore);
    }
}
