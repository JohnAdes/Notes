package com.johnson.cgdiner.api_controller;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.models.Store;
import com.johnson.cgdiner.repo.ProductRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/products")
public class ProdController {

    @Autowired
    private ProductRepo productRepo;

   @GetMapping
    public List<Product> list(){
       return productRepo.findAll();
   }

   @GetMapping
    @RequestMapping("{id")
    public Product get(@PathVariable Long id) {
       return productRepo.getById(id);
   }

    @PostMapping
    public Product create(@RequestBody final Product product){
        return  productRepo.saveAndFlush(product);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    public void delete(@PathVariable Long id){
        productRepo.deleteById(id);
    }

    @RequestMapping(value = "{id}", method = RequestMethod.PUT)
    public Product update(@PathVariable Long id, @RequestBody Product product){
        Product existingProduct = productRepo.getById(id);
        BeanUtils.copyProperties(product, existingProduct, "product_id");
        return productRepo.saveAndFlush(existingProduct);
    }
}

