package com.johnson.cgdiner.repo;

import com.johnson.cgdiner.models.Product;
import com.johnson.cgdiner.models.Store;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepo extends JpaRepository<Product, Long> {

    List<Product> findByStore(Store store);
    List<Product> findByStoreAndName(Store store, String name);
}
