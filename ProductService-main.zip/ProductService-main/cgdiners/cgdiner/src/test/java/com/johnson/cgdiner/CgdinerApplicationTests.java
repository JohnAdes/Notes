package com.johnson.cgdiner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CgdinerApplicationTests {

	@Test
	void contextLoads() {
	}

}
