package com.WSR.WSR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsrApplicationTests {

	@Test
	void contextLoads() {
	}

}
