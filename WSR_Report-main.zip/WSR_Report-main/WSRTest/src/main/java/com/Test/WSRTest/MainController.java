package com.Test.WSRTest;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public boolean userFound = false;
	public boolean validPass = false;
	public String empRole = "";
	
	Report[] reports = new Report[200];
	User[] users = new User[30];
	
	int reportIt = 0;
	int userIt = 0;
	
	
	@GetMapping("/login")
	public String showLoginForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "login_form";
	}
	
	@PostMapping("/login")
	public String submitLoginForm(@ModelAttribute("user") User user) {
		
		initializeTables();
		
		
		//Validate Login info
				String query2 = "SELECT * FROM account";
				List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query2);
				
				
				accounts.forEach( rowMap -> {
					if (user.getEmp_username().equals((String)rowMap.get("emp_username"))) {
						userFound = true;
						if (user.getPassword().equals((String)rowMap.get("password"))) {
							validPass = true;
							empRole = (String)rowMap.get("emp_role");
						}
					}
				});
		
		//Valid login
		if (userFound == true && validPass == true) {
			
			//Supervisor Page
			if (empRole.equals("S")) {
				return "supHome";
			}
			
			else {
				return "empHome";
			}
		}
		
		//Invalid Password
		else if (userFound == true && validPass == false) {
			userFound = false;
			return "invalidPass";
		}
		
		else {
			userFound = false;
			validPass = false;
			return "invalidUser";
		}
		
	}
	
	@GetMapping("/register")
	public String showRegForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "register_form";
	}
	
	@PostMapping("/register")
	public String submitRegForm(@ModelAttribute("user") User user) {
		
		//INSERT new user into database
		String sql = "INSERT INTO account (first_name, last_name, emp_role, email, emp_username, password) VALUES (?, ?, ?, ?, ?, ?)";
		int result = jdbcTemplate.update(sql, user.getFirst_name(), user.getLast_name(), user.getEmp_role(), user.getEmail(), user.getEmp_username(), user.getPassword());
	
		if (result > 0) {
			System.out.println("A new row has been inserted");
		}
		
		
		//SELECT accounts from database (check that user has been added)
				String query = "SELECT * FROM account";
				List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query);
				
				System.out.println();
				System.out.println();
				
				accounts.forEach( rowMap -> {
					String first_name = (String)rowMap.get("first_name");
					String last_name = (String)rowMap.get("last_name");
					String emp_role = (String)rowMap.get("emp_role");
					String email = (String)rowMap.get("email");
					String emp_username = (String)rowMap.get("emp_username");
					String password = (String)rowMap.get("password");
					
					System.out.println("first_name" + " - " + first_name + " - " + "last_name" + " - " + last_name + " - "+"emp_role" + " - " + emp_role + " - " +"email" + " - " + email + " - " + "emp_username" + " - " + emp_username + " - " + "password" + " - " + password);
				});
		return "register_success";
	}
	
	@GetMapping("/createReport")
	public String showRepForm(Model model) {
		Report report = new Report();
		model.addAttribute("report", report);
		return "createReport";
	}
	
	@PostMapping("/createReport")
	public String submitRepForm(@ModelAttribute("report") Report report) {
		
		//INSERT new report into database
		String sql = "INSERT INTO report (work_week, emp_username, proj_name, hours_worked, report_date, completed_items, plan_to_complete, roadblocks, milestones, task_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int result = jdbcTemplate.update(sql, report.getWork_week(), report.getEmp_username(), report.getProj_name(), report.getHours_worked(), report.getReport_date(), report.getCompleted_items(), report.getPlan_to_complete(), report.getRoadblocks(), report.getMilestones(), report.getTask_name());
	
		if (result > 0) {
			System.out.println("A new row has been inserted");
		}
		
		
		//SELECT reports from database (check that report has been added)
				String query = "SELECT * FROM report";
				List<Map<String, Object>> reports = jdbcTemplate.queryForList(query);
				
				System.out.println();
				System.out.println();
				
				reports.forEach( rowMap -> {
					String emp_username = (String)rowMap.get("emp_username");
					String proj_name = (String)rowMap.get("proj_name");
					Date report_date = (Date)rowMap.get("report_date");
					String completed_items = (String)rowMap.get("completed_items");
					
					
					System.out.println("Username" + " - " + emp_username + " - " + "Project Name" + " - " + proj_name + " - "+"Report Date" + " - " + report_date.toString() + " - " +"Completed Items" + " - " + completed_items);
				});
		return "empHome";
	}
	
	@GetMapping("/viewReports")
	public String showRepsForm(Model model) {
		Report report = new Report();
		model.addAttribute("report", report);
		return "viewReports";
	}
	
	@PostMapping("/viewReports")
	public String returnEmpHome(@ModelAttribute("report") Report report) {
		
		return "empHome";
	}
	
	public void initializeTables() {
		
		//Initialize Users Array
		String query1 = "SELECT * FROM account";
		List<Map<String, Object>> accounts = jdbcTemplate.queryForList(query1);
		
		
		accounts.forEach( rowMap -> {
			
			String first_name = (String)rowMap.get("first_name");
			String last_name = (String)rowMap.get("last_name");
			String emp_role = (String)rowMap.get("emp_role");
			String email = (String)rowMap.get("email");
			String emp_username = (String)rowMap.get("emp_username");
			String password = (String)rowMap.get("password");
			
			User addUser = new User();
			addUser.setFirst_name(first_name);
			addUser.setLast_name(last_name);
			addUser.setEmp_role(emp_role);
			addUser.setEmail(email);
			addUser.setEmp_username(emp_username);
			addUser.setPassword(password);
			
			users[userIt] = addUser;
			userIt++;
		});
		
		//Initialize Reports Array
				String query2 = "SELECT * FROM report";
				List<Map<String, Object>> rep = jdbcTemplate.queryForList(query2);
				
				rep.forEach( rowMap -> {
					Date work_week = (Date)rowMap.get("work_week");
					String emp_username = (String)rowMap.get("emp_username");
					String proj_name = (String)rowMap.get("proj_name");
					int hours_worked = (int)rowMap.get("hours_worked");
					Date report_date = (Date)rowMap.get("report_date");
					String completed_items = (String)rowMap.get("completed_items");
					String plan_to_complete = (String)rowMap.get("plan_to_complete");
					String roadblocks = (String)rowMap.get("roadblocks");
					String milestones = (String)rowMap.get("milestones");
					String task_name = (String)rowMap.get("task_name");
					
					Report addReport = new Report();
					addReport.setWork_week(work_week);
					addReport.setEmp_username(emp_username);
					addReport.setProj_name(proj_name);
					addReport.setHours_worked(hours_worked);
					addReport.setReport_date(report_date);
					addReport.setCompleted_items(completed_items);
					addReport.setPlan_to_complete(plan_to_complete);
					addReport.setRoadblocks(roadblocks);
					addReport.setMilestones(milestones);
					addReport.setTask_name(task_name);
					
					reports[reportIt] = addReport;
					reportIt++;
				});
				
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println("TEST ACCOUNT ARRAY");
				for (int i = 0; i < users.length; i++) {
					if (users[i] != null) {
						System.out.println(users[i].getFirst_name() + " " + users[i].getLast_name() + " " + users[i].getEmp_role());
					}
				}
				System.out.println();
				System.out.println();
				System.out.println();
				
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println("TEST REPORT ARRAY");
				for (int i = 0; i < reports.length; i++) {
					if (reports[i] != null) {
						System.out.println(reports[i].getEmp_username() + reports[i].getReport_date());
					}
				}
				System.out.println();
				System.out.println();
				System.out.println();
	}
	
}
