package com.Test.WSRTest;

import java.sql.Date;

public class Report {
	private Date work_week;
	private String emp_username;
	private String proj_name;
	private int hours_worked;
	private Date report_date;
	private String completed_items;
	private String plan_to_complete;
	private String roadblocks;
	private String milestones;
	private String task_name;
	public Date getWork_week() {
		return work_week;
	}
	public void setWork_week(Date work_week) {
		this.work_week = work_week;
	}
	public String getEmp_username() {
		return emp_username;
	}
	public void setEmp_username(String emp_username) {
		this.emp_username = emp_username;
	}
	public String getProj_name() {
		return proj_name;
	}
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	public int getHours_worked() {
		return hours_worked;
	}
	public void setHours_worked(int hours_worked) {
		this.hours_worked = hours_worked;
	}
	public Date getReport_date() {
		return report_date;
	}
	public void setReport_date(Date report_date) {
		this.report_date = report_date;
	}
	public String getCompleted_items() {
		return completed_items;
	}
	public void setCompleted_items(String completed_items) {
		this.completed_items = completed_items;
	}
	public String getPlan_to_complete() {
		return plan_to_complete;
	}
	public void setPlan_to_complete(String plan_to_complete) {
		this.plan_to_complete = plan_to_complete;
	}
	public String getRoadblocks() {
		return roadblocks;
	}
	public void setRoadblocks(String roadblocks) {
		this.roadblocks = roadblocks;
	}
	public String getMilestones() {
		return milestones;
	}
	public void setMilestones(String milestones) {
		this.milestones = milestones;
	}
	public String getTask_name() {
		return task_name;
	}
	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}
	@Override
	public String toString() {
		return "Report [work_week=" + work_week + ", emp_username=" + emp_username + ", proj_name=" + proj_name
				+ ", hours_worked=" + hours_worked + ", report_date=" + report_date + ", completed_items="
				+ completed_items + ", plan_to_complete=" + plan_to_complete + ", roadblocks=" + roadblocks
				+ ", milestones=" + milestones + ", task_name=" + task_name + "]";
	}
	
	
}
