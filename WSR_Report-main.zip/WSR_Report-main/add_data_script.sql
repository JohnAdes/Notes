
/*
	ACCOUNT TABLE
*/
INSERT INTO account (first_name, last_name, emp_role, email, emp_username, password)
VALUES 
	('Varsha', 'Saravanan', 'E', 'VarshaS@cap.com', 'VarshaS', '1234'),
    ('Johnson', 'Adeshina', 'E', 'JohnsonA@cap.com', 'JohnsonA', '1234'),
    ('Edvige', 'Djouapouo', 'E', 'EdvigeD@cap.com', 'EdvigeD', '1234'),
    ('Emma', 'Hermick', 'E', 'EmmaH@cap.com', 'EmmaH', '1234'),
    ('Niladri', 'Sadhukhan', 'S', 'NiladriS@cap.com', 'NiladriS', '1234');

/*
	PROJECT TABLE
*/
INSERT INTO project (proj_name, start_date, end_date, client_name, proj_goal)
VALUES 
	('Project1', '2021-10-01', NULL, 'Client1', 'Project #1 Goal'),
	('Project2', '2021-09-01', '2021-12-20', 'Client2', 'Project #2 Goal'),
    ('Project3', '2021-09-01', '2021-12-20', 'Client1', 'Project #3 Goal'),
    ('Project4', '2021-10-01', NULL, 'Client3', 'Project #4 Goal');

/*
	REPORT TABLE
*/

INSERT INTO report (work_week, emp_username, proj_name, hours_worked, report_date, completed_items, plan_to_complete, roadblocks, milestones, task_name)
VALUES 
	('2021-10-18', 'VarshaS', 'Project1', 4, '2021-10-18', 'Completed Project1 Task #1 & Task #3', 'Plan to complete Project1 Task #4', NULL, NULL, 'Task1'),
    ('2021-10-18', 'VarshaS', 'Project1', 2, '2021-10-19', 'Completed Project1 Task #4', 'Plan to complete Project1 Task #6 & Task #7', NULL, NULL, 'Task4'),
    ('2021-10-18', 'VarshaS', 'Project2', 7, '2021-10-19', 'Completed Project2 Task #1', 'Plan to complete Project1 Task #2', NULL, NULL, 'Task1'),
    ('2021-10-18', 'VarshaS', 'Project1', 6, '2021-10-20', 'Completed Project1 Task #6 & Task #7', 'Plan to complete Project1 Task #8', NULL, NULL, 'Task6'),
    ('2021-10-18', 'VarshaS', 'Project1', 5, '2021-10-21', NULL, NULL, 'Overestimed the necessary time to complete', NULL, 'Task8'),
    ('2021-10-18', 'VarshaS', 'Project1', 3, '2021-10-22', 'Completed Project1 Task #8', NULL, NULL, 'Completed first section of tasks in Project1', 'Task8'),
    ('2021-10-18', 'VarshaS', 'Project2', 4, '2021-10-22', 'Completed Project2 Task #2 & Task #3', NULL, NULL, NULL, 'Task2');

INSERT INTO report (work_week, emp_username, proj_name, hours_worked, report_date, completed_items, plan_to_complete, roadblocks, milestones, task_name)
VALUES 
	('2021-10-18', 'EmmaH', 'Project3', 6, '2021-10-18', 'Completed Project3 Task #1', 'Plan to complete Project3 Task #3', NULL, NULL, 'Task1'),
    ('2021-10-18', 'EmmaH', 'Project3', 7, '2021-10-19', 'Completed Project3 Task #3', 'Plan to complete Project3 Task #7', NULL, NULL, 'Task3'),
    ('2021-10-18', 'EmmaH', 'Project3', 8, '2021-10-20', NULL, 'Plan to complete Project3 Task #7', 'Found the topic challenging', NULL, 'Task7'),
    ('2021-10-18', 'EmmaH', 'Project3', 5, '2021-10-21', 'Completed Project3 Task #7', 'Plan to complete Project3 Task #9', NULL, NULL, 'Task7'),
    ('2021-10-18', 'EmmaH', 'Project3', 4, '2021-10-22', 'Completed Project3 Task #9', NULL, NULL, 'Completed Project3 first section!', 'Task9');

INSERT INTO report (work_week, emp_username, proj_name, hours_worked, report_date, completed_items, plan_to_complete, roadblocks, milestones, task_name)
VALUES 
	('2021-10-18', 'EdvigeD', 'Project3', 3, '2021-10-18', 'Completed Project3 Task #2', 'Plan to complete Project3 Task #4', NULL, NULL, 'Task2'),
    ('2021-10-18', 'EdvigeD', 'Project1', 5, '2021-10-18', 'Completed Project1 Task #2', 'Plan to complete Project1 Task #5', NULL, NULL, 'Task2'),
    ('2021-10-18', 'EdvigeD', 'Project1', 3, '2021-10-19', 'Completed Project1 Task #5', 'Plan to complete Project1 Task #6', NULL, NULL, 'Task5'),
    ('2021-10-18', 'EdvigeD', 'Project3', 6, '2021-10-19', 'Completed Project3 Task #4', 'Plan to complete Project3 Task #5', NULL, NULL, 'Task4'),
    ('2021-10-18', 'EdvigeD', 'Project3', 9, '2021-10-20', 'Completed Project3 Task #5 & Task #6', 'Plan to complete Project3 Task #8', NULL, NULL, 'Task5'),
    ('2021-10-18', 'EdvigeD', 'Project1', 4, '2021-10-21', NULL, NULL, 'High workload', NULL, 'Task8'),
    ('2021-10-18', 'EdvigeD', 'Project3', 2, '2021-10-21', NULL, NULL, 'Difficulties with software', NULL, 'Task8'),
    ('2021-10-18', 'EdvigeD', 'Project3', 2, '2021-10-22', 'Completed Project3 Task #8', NULL, NULL, 'Completed Project3 first section!', 'Task8'),
    ('2021-10-18', 'EdvigeD', 'Project1', 7, '2021-10-22', 'Completed Project1 Task #9', NULL, NULL, 'Completed Project1 first section!', 'Task9');

INSERT INTO report (work_week, emp_username, proj_name, hours_worked, report_date, completed_items, plan_to_complete, roadblocks, milestones, task_name)
VALUES 
	('2021-10-18', 'JohnsonA', 'Project4', 6, '2021-10-18', 'Completed Project4 Task #1', 'Plan to complete Project4 Task #2', NULL, NULL, 'Task1'),
	('2021-10-18', 'JohnsonA', 'Project4', 8, '2021-10-19', 'Completed Project4 Task #2', 'Plan to complete Project4 Task #3', NULL, NULL, 'Task2'),
	('2021-10-18', 'JohnsonA', 'Project4', 5, '2021-10-20', 'Completed Project4 Task #3 & Task #4', 'Plan to complete Project4 Task #4', NULL, NULL, 'Task3'),
    ('2021-10-18', 'JohnsonA', 'Project4', 7, '2021-10-21', NULL, NULL, 'Technical issues', NULL, 'Task5'),
	('2021-10-18', 'JohnsonA', 'Project4', 9, '2021-10-22', 'Completed Project4 Task #5', NULL, NULL, 'Completed Project4 first section!', 'Task5');

/*
	REPORT_HISTORY TABLE
*/
INSERT INTO report_history (emp_username, work_week, proj_name)
VALUES 
	('VarshaS', '2021-10-18', 'Project1'),
	('VarshaS', '2021-10-18', 'Project2'),
    ('EmmaH', '2021-10-18', 'Project3'),
    ('EdvigeD', '2021-10-18', 'Project1'),
    ('EdvigeD', '2021-10-18', 'Project3'),
    ('JohnsonA', '2021-10-18', 'Project4');
    
    
/*
	PROJECT_SUP_ASSIGNED TABLE
*/   
INSERT INTO project_sup_assigned (sup_assigned, proj_name)
VALUES 
	('NiladriS', 'Project1'),
    ('NiladriS', 'Project2'),
    ('NiladriS', 'Project3'),
    ('NiladriS', 'Project4');
    
    
/*
	PROJECT_EMP_ASSIGNED TABLE
*/   
INSERT INTO project_emp_assigned (emp_assigned, proj_name)
VALUES 
	('VarshaS', 'Project1'),
    ('VarshaS', 'Project2'),
    ('EmmaH', 'Project3'),
	('EdvigeD', 'Project1'),
    ('EdvigeD', 'Project3'),
    ('JohnsonA', 'Project4');


