package com.capgemini.cpdemo.controllers;

import com.capgemini.cpdemo.models.Employee;
import com.capgemini.cpdemo.services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

    @Autowired
    private EmployeeService emplService;

    @RequestMapping(value = { "/"})
    public ModelAndView index() {
        ModelAndView model = new ModelAndView();
        model.setViewName("/index");
        return model;
    }

    @GetMapping("/login")
    public String login(Model model) {
    	model.addAttribute("loginIn", new Employee());
        return "login";
    }
    
    @PostMapping("/login")
    public String loginInfo(@ModelAttribute("loginIn") Employee emp) {
    	System.out.println("Email: " + emp.getEmail());
    	return "Test Email";
    	//return "page to redirect to";
    }

//	@RequestMapping(value = { "/admin" }, method = RequestMethod.GET)
//	public ModelAndView adminlogin() {
//		ModelAndView model = new ModelAndView();
//		model.setViewName("admin/admin");
//		return model;
//	}

    @RequestMapping(value = { "/registration" }, method = RequestMethod.GET)
    public ModelAndView register() {
        ModelAndView model = new ModelAndView();
        Employee employee = new Employee();
        model.addObject("employee",employee);
        model.setViewName("employee/registration");
        return model;
    }
//
//    @RequestMapping(value = { "/registration" }, method = RequestMethod.POST)
//    public ModelAndView createEmployee(@Valid Employee employee, BindingResult bindingResult) {
//        ModelAndView model = new ModelAndView();
//        Employee employeeExists = emplService.findEmployeeByEmail(employee.getEmail());
//
//        if (employeeExists != null) {
//            bindingResult.rejectValue("email", "error.employee", "This email already exists!");
//        }
//        if (bindingResult.hasErrors()) {
//            model.setViewName("employee/registration");
//        } else {
//            emplService.saveEmployee(employee);
//            model.addObject("msg", "Employee has been registered successfully!");
//            //model.addObject("employee", new Employee());
//            model.setViewName("employee/login");
//        }
//        return model;
//    }
    @PostMapping("/registration")
    public String registerEmployee(@ModelAttribute("employee") Employee employee) {
    emplService.saveEmployee(employee);
    return "redirect:/employee/registration?success";
}



    @RequestMapping(value = { "/dashboard" }, method = RequestMethod.GET)
    public ModelAndView showDashboard() {
        ModelAndView model = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Employee employee = emplService.findEmployeeByEmail(auth.getName());

        model.addObject("employeeName", employee.getFirstname() + " " + employee.getLastname());
        model.setViewName("employee/dashboard");
        return model;
    }

    @RequestMapping(value = { "/access_denied" }, method = RequestMethod.GET)
    public ModelAndView accessDenied() {
        ModelAndView model = new ModelAndView();
        model.setViewName("errors/access_denied");
        return model;
    }
}