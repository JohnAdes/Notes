package com.capgemini.cpdemo.services;

import com.capgemini.cpdemo.models.Report;
import com.capgemini.cpdemo.models.Task;
import com.capgemini.cpdemo.repos.TaskRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    @Autowired
    private TaskRepo taskRepo;

    public List<Task> getTaskList() {
        return taskRepo.findAll();
    }
    public List<Task> getTaskListByReport(Report report) {
        return taskRepo.findByReport(report);
    }

    public void saveTask(Task task) {
        taskRepo.save(task);
    }

    public Task getTaskById(int id) {
        return taskRepo.findById(id).get();
    }

    public void deleteTask(int id) {
        taskRepo.deleteById(id);
    }
}
