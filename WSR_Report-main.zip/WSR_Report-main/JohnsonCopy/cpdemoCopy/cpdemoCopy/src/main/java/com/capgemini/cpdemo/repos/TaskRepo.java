package com.capgemini.cpdemo.repos;

import com.capgemini.cpdemo.models.Report;
import com.capgemini.cpdemo.models.Task;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskRepo extends JpaRepository<Task, Integer> {
    //Method to find the list of tasks belonging to a report
    List<Task> findByReport(Report report);
}