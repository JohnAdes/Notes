package com.capgemini.cpdemo.services;

import com.capgemini.cpdemo.models.Employee;
import com.capgemini.cpdemo.models.Report;
import com.capgemini.cpdemo.repos.ReportRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportService {

    @Autowired
    private ReportRepo reportRepo;

    //Method to find all the properties
    public List<Report> getPropertyList() {
        return reportRepo.findAll();
    }

    //Method to save a task after creating a new report or updating an existing report
    public void saveReport(Report report) {
        reportRepo.save(report);
    }

    //Method to find report based on id
    public Report getReportById(int id) {
        return reportRepo.findById(id).get();
    }

    //Method to delete report based on id
    public void deleteReport(int id) {
        reportRepo.deleteById(id);
    }

    //Method to get the report of a user
    public Report getEmployeeReport(Employee employee) {
        return reportRepo.findByEmployee(employee);
    }
}
