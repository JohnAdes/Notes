package com.capgemini.cpdemo.models;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @DateTimeFormat(pattern = "mm-dd-yyyy")
    private LocalDate date;
    private String projectName;
    private String Description;


    @ManyToOne
    @JoinColumn(name="report_id",referencedColumnName = "id")
    private Report report;

//    @OneToMany(mappedBy="task",cascade = CascadeType.ALL)
//    private List<Project> project;

    //Constructors
    public Task() {

    }

    public Task(String projectName) {
        this.projectName = projectName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String name) {
        this.projectName = projectName;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }
}