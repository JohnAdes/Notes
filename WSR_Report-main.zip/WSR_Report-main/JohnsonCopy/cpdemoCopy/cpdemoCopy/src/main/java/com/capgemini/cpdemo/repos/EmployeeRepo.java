package com.capgemini.cpdemo.repos;

import com.capgemini.cpdemo.models.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {
    //Method to find user object based on the email
    Employee findByEmail(String email);
}