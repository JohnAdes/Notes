package com.capgemini.cpdemo.models;

//import javax.persistence.*;
//import java.time.LocalDate;
//import java.util.Objects;
//
//@Entity
//public class Project {
//        @Id
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
////        @Column(name = "id", unique = true, nullable = false)
//        private int id;
//
//        @Column(name = "client_name")
//        private String clientName;
//
//        @Column(name = "supervisor")
//        private String supervisor;
//
//        @Column(name = "hours_worked")
//        private double hoursWorked;
//
//        @DateTimeFormat(pattern = "dd/mm/yyyy")
//        @Column(name = "project_week")
//        private LocalDate projectWeek;
//
//    @ManyToOne
//    @JoinColumn(name="task_id",referencedColumnName = "id")
//    private Task task;
//
//
//
////    @Enumerated(EnumType.STRING)
////    @Column(name = "category")
////    private TaskCategories category;
//
//        @Column(name = "status")
//        private String status;
//
//        @Column(name = "account_id")
//        private int accountId;
//
//        @Override
//        public boolean equals(Object o) {
//            if (this == o) return true;
//            if (o == null || getClass() != o.getClass()) return false;
//            com.capgemini.cpdemo.models.Project project = (com.capgemini.cpdemo.models.Project) o;
//            return id == project.id &&
//                    accountId == project.accountId &&
//                    Objects.equals(clientName, project.clientName) &&
//                    Objects.equals(projectWeek, project.projectWeek) &&
//                    Objects.equals(hoursWorked, project.hoursWorked) &&
//                    Objects.equals(supervisor, project.supervisor) &&
////                    Objects.equals(createDate, task.createDate) &&
////                category == task.category &&
//                    Objects.equals(status, project.status);
//        }
//
//        @Override
//        public int hashCode() {
//
//            return Objects.hash(id, clientName, projectWeek, hoursWorked, supervisor, status, accountId);
//        }
//    }
//
//
