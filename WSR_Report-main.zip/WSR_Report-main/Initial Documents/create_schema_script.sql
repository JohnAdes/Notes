CREATE SCHEMA wsr_schema;

CREATE TABLE Account
(
  first_name VARCHAR(30) NOT NULL,
  last_name VARCHAR(30) NOT NULL,
  emp_role VARCHAR(1) NOT NULL,
  email VARCHAR(30) NOT NULL,
  emp_username VARCHAR(30) NOT NULL,
  password VARCHAR(30) NOT NULL,
  PRIMARY KEY (email),
  UNIQUE (emp_username)
);

CREATE TABLE Project
(
  proj_name VARCHAR(30) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  client_name VARCHAR(30) NOT NULL,
  proj_goal VARCHAR(100) NOT NULL,
  PRIMARY KEY (proj_name)
);

CREATE TABLE Report
(
  work_week DATE NOT NULL,
  emp_username VARCHAR(30) NOT NULL,
  proj_name VARCHAR(30) NOT NULL,
  hours_worked INT NOT NULL,
  report_date DATE NOT NULL,
  completed_items VARCHAR(300), 
  plan_to_complete VARCHAR(300),
  roadblocks VARCHAR(300),
  milestones VARCHAR(300)
);

CREATE TABLE Report_History
(
  emp_username VARCHAR(30) NOT NULL,
  work_week DATE NOT NULL,
  proj_name VARCHAR(30) NOT NULL
);

CREATE TABLE Project_sup_assigned
(
  sup_assigned VARCHAR(30) NOT NULL,
  proj_name VARCHAR(30) NOT NULL,
  PRIMARY KEY (sup_assigned, proj_name),
  FOREIGN KEY (proj_name) REFERENCES Project(proj_name)
);

CREATE TABLE Project_emp_assigned
(
  emp_assigned VARCHAR(30),
  proj_name VARCHAR(30) NOT NULL,
  PRIMARY KEY (emp_assigned, proj_name),
  FOREIGN KEY (proj_name) REFERENCES Project(proj_name)
);

CREATE TABLE tasks
(
	task_name VARCHAR(30),
    task_description VARCHAR(300),
    proj_name VARCHAR(30)
);