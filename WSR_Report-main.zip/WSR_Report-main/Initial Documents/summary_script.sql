/*
	View all employees that are assigned to Project1
*/  
SELECT a.first_name, a.last_name, a.emp_role, p.proj_name
FROM account a
JOIN project_emp_assigned p
ON a.emp_username = p.emp_assigned
WHERE p.proj_name = 'Project1';

/*
	View all projects Varsha is assigned to
*/ 
SELECT proj_name
FROM project_emp_assigned
WHERE emp_assigned = 'VarshaS';

/*
	View Emma's reports for the week of 10/18/2021
*/ 
SELECT * 
FROM report
WHERE emp_username = 'EmmaH'
AND work_week = '2021-10-18';

/*
	How many hours has Edvige worked for the week of 10/18/2021?
*/ 
SELECT work_week, SUM(hours_worked) AS 'Hours Worked'
FROM report
WHERE emp_username = 'EdvigeD';

/*
	How many projects does Client1 have right now?
*/ 
SELECT COUNT(*)
FROM project
WHERE client_name = 'Client1';

/*
	What items did Varsha complete on 10/20/2021?
*/
SELECT emp_username, report_date, completed_items
FROM report
WHERE report_date = '2021-10-20'
AND emp_username = 'VarshaS';