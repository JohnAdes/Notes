package com.capgemini.cpdemo;

import org.testng.annotations.Test;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
