package com.capgemini.cpdemo.models;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

enum DefaultTask {
    Activity, Training, Meeting;
}

@Entity
public class Report {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    private LocalDate work_week;
    private String proj_name;
    private int hours_worked;
    private LocalDate report_date;
//    private String completed_items;
    private String plan_to_complete;
    private String roadblocks;
    private String milestones;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="employeeid",referencedColumnName = "id")
    private Employee employee;

    @OneToMany(mappedBy="report",cascade = CascadeType.ALL)
    private List<Task> task;

    public ArrayList<Task> createDefaultTasks() {
        DefaultTask[] arr = DefaultTask.values();
        ArrayList<Task> taskCompleted = new ArrayList<Task>();
        for(int i=0;i<arr.length;i++) {
            Task t = new Task(arr[i].toString());
            t.setReport(this);
            taskCompleted.add(t);
        }
        return taskCompleted;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getWork_week() {
        return work_week;
    }

    public void setWork_week(LocalDate work_week) {
        this.work_week = work_week;
    }

    public LocalDate getReport_date() {
        return report_date;
    }

    public void setReport_date(LocalDate report_date) {
        this.report_date = report_date;
    }

    public String getProj_name() {
        return proj_name;
    }

    public void setProj_name(String proj_name) {
        this.proj_name = proj_name;
    }

    public int getHours_worked() {
        return hours_worked;
    }

    public void setHours_worked(int hours_worked) {
        this.hours_worked = hours_worked;
    }


//    public String getCompleted_items() {
//        return completed_items;
//    }
//
//    public void setCompleted_items(String completed_items) {
//        this.completed_items = completed_items;
//    }

    public String getPlan_to_complete() {
        return plan_to_complete;
    }

    public void setPlan_to_complete(String plan_to_complete) {
        this.plan_to_complete = plan_to_complete;
    }

    public String getRoadblocks() {
        return roadblocks;
    }

    public void setRoadblocks(String roadblocks) {
        this.roadblocks = roadblocks;
    }

    public String getMilestones() {
        return milestones;
    }

    public void setMilestones(String milestones) {
        this.milestones = milestones;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public List<Task> getTask() {
        return task;
    }

    public void setTask(List<Task> task) {
        this.task = task;
    }
}
