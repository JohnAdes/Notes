package com.capgemini.cpdemo.controllers;

import com.capgemini.cpdemo.models.Employee;
import com.capgemini.cpdemo.models.Report;
import com.capgemini.cpdemo.models.Task;
import com.capgemini.cpdemo.services.EmployeeService;
import com.capgemini.cpdemo.services.ReportService;
import com.capgemini.cpdemo.services.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.ArrayList;

public class ReportController {

    @Autowired
    private ReportService reportService;

    @Autowired
    private EmployeeService emplService;
    @Autowired
    private TaskService taskService;

    @RequestMapping(value = {"/employee/report"}, method = RequestMethod.GET)
    public ModelAndView home(Principal principal) {
        ModelAndView model = new ModelAndView();
//		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//		Employee employee =(Employee) auth.getPrincipal();
        Employee employee = emplService.findEmployeeByEmail(principal.getName());
        Report report = reportService.getEmployeeReport(employee);
        //model.addObject("userName", user.getFirstname() + " " + user.getLastname());
        if (report != null) {
            System.out.println("Report=" + report.getEmployee().getUsername());
            model.addObject("update", true);
            model.addObject(report);
        } else {
            Report newReport = new Report();
            newReport.setEmployee(employee);

            model.addObject("update", false);
            model.addObject("report", newReport);
        }
        model.setViewName("employee/report");
        return model;
    }


    @RequestMapping(value = "/employee/report", method = RequestMethod.POST)
    public String saveReport(@ModelAttribute("report") Report report, Principal principal, Model model) {
        Employee employee = emplService.findEmployeeByEmail(principal.getName());
        Report existingReport = reportService.getEmployeeReport(employee);
        reportService.saveReport(report);
        if (existingReport == null) {
            ArrayList<Task> tList = report.createDefaultTasks();
            for (int i = 0; i < tList.size(); i++) {

                taskService.saveTask(tList.get(i));
            }
        }
        model.addAttribute("update", true);
        return "employee/report";
    }
}