package com.capgemini.cpdemo.controllers;

import com.capgemini.cpdemo.models.Report;
import com.capgemini.cpdemo.models.Task;
import com.capgemini.cpdemo.services.ReportService;
import com.capgemini.cpdemo.services.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/employee/task")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private ReportService reportService;

    @RequestMapping("/{id}")
    public String viewTaskPage(@PathVariable(name="id") int id,Model model) {
        //System.out.println("inside rooms.."+roomList.get(0).getName());
        Report report = reportService.getReportById(id);
        List<Task> taskList=taskService.getTaskListByReport(report);

        model.addAttribute("report", report);
        model.addAttribute("taskList", taskList);
        return "employee/task/task";
    }

    @RequestMapping(value="/new/{id}",method=RequestMethod.GET)
    public String addTask(@PathVariable(name="id") int id, Model model) {
        Task task = new Task();
        System.out.println("addtask........");
        Report report = reportService.getReportById(id);
        task.setReport(report);
        model.addAttribute("report",report);
        model.addAttribute("task", task);
        return "employee/task/new";
    }

    @RequestMapping("/edit/{id}")
    public ModelAndView editTask(@PathVariable(name="id") int id) {
        System.out.println("inside edit,id= "+id);
        ModelAndView mav = new ModelAndView();
        Task task = taskService.getTaskById(id);

        mav.addObject("task",task);
        mav.setViewName("employee/task/edit");
        return mav;
    }

    @RequestMapping("/view/{id}")
    public ModelAndView viewTask(@PathVariable(name="id") int id) {
        ModelAndView mav = new ModelAndView();
        Task task = taskService.getTaskById(id);

        mav.addObject("task",task);
        mav.setViewName("employee/task/view");
        return mav;
    }

    @RequestMapping(value = "view/delete", method= RequestMethod.POST)
    public String deleteTask(@ModelAttribute("task") Task task) {
        int rId = task.getReport().getId();

        taskService.deleteTask(task.getId());
        System.out.println("Record deleted");
        return "redirect:/employee/task/"+rId;
    }

    @RequestMapping(value="/save", method=RequestMethod.POST)
    public String saveTask(@ModelAttribute("task") Task task) {
        taskService.saveTask(task);
        int id = task.getReport().getId();
        System.out.println("Task saved");
        System.out.println("id="+id);
        return "redirect:/employee/task/"+id;

    }

}
