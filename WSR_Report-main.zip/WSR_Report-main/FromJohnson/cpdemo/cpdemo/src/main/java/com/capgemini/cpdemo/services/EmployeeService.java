package com.capgemini.cpdemo.services;

import com.capgemini.cpdemo.models.Employee;
import com.capgemini.cpdemo.models.Role;
import com.capgemini.cpdemo.repos.EmployeeRepo;
import com.capgemini.cpdemo.repos.RoleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashSet;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepo employeeRepo;
    @Autowired
    private RoleRepo roleRepo;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public Employee findEmployeeByEmail(String email) {
        return employeeRepo.findByEmail(email);
    }

    public void saveEmployee(Employee employee) {
        employee.setPassword(bCryptPasswordEncoder.encode(employee.getPassword()));
        employee.setActive(1);
        Role employeeRole = roleRepo.findByRole("EMPLOYEE");
        employee.setRoles(new HashSet<Role>(Arrays.asList(employeeRole)));
        employeeRepo.save(employee);
    }
}
