package com.capgemini.cpdemo.repos;

import com.capgemini.cpdemo.models.Employee;
import com.capgemini.cpdemo.models.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepo extends JpaRepository<Report, Integer> {
    //Method to find the report of an employee
    Report findByEmployee(Employee employee);
}
