package com.capgemini.cpdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpdemoApplication.class, args);
	}

}
