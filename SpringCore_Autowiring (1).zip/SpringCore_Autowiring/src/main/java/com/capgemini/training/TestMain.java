package com.capgemini.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {
public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("my_springbean.xml");
	Employee emp=(Employee)context.getBean("empObject");
	System.out.println("Please check the hashcode");
	System.out.println("====================================");
	System.out.println(emp);
	
	Employee emp1=(Employee)context.getBean("empObject");
	System.out.println(emp1);
	
	Employee emp2=(Employee)context.getBean("empObject");
	System.out.println(emp2);
	
	Employee emp3=(Employee)context.getBean("empObject");
	System.out.println(emp3);
	
	Employee emp4=(Employee)context.getBean("empObject");
	System.out.println(emp4);



}
}
