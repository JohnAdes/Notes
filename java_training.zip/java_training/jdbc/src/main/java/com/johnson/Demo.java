package com.johnson;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {
    public static void main(String[] args) {
        Connection con=null;
        Statement stmt=null;
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded Successfully");
        }catch(ClassNotFoundException e)
        {
            System.out.println("Driver not Loaded Successfully");
        }
        try
        {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Java_evening", "root", "password");
            System.out.println("Connection Eastablished Successfully");
            stmt=con.createStatement();
//String cs="CREATE TABLE EMP(empId int,empName varchar(20),empSal int)";
//stmt.execute(cs);
            String cs="Select * from emp";
            ResultSet rs=stmt.executeQuery(cs);
            ResultSetMetaData rsmd=rs.getMetaData();
            int cols=rsmd.getColumnCount();
            while(rs.next())
            {
                for(int i=1;i<=cols;i++)
                {
                    String s=rs.getString(i);
                    System.out.print(s+" ");
                }
                System.out.println();
            }
            stmt.close();
        }catch(SQLException e)
        {
            System.out.println("Connection not established");
        }
        finally
        {
            try {
                con.close();
            } catch (SQLException e) {
// TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    }
}