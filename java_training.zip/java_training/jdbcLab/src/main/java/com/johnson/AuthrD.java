package com.johnson;

import java.sql.*;

public class AuthrD {

    private static final String createTableSQL = "create table author_d (\r\n" + " authorId int primary key,\r\n" +
            "  firstName varchar(20),\r\n" + "  middleName varchar(20),\r\n" + "  lastName varchar(20),\r\n" +
            "  phoneNo varchar(20)\r\n" + "  );";

    private static final String insertAuthrD = "INSERT INTO author_d" +
            "  (authorId, firstName, middleName, lastName, phoneNo) VALUES " +
            " (?, ?, ?, ?, ?);";

    private static final String queryAuthrD = "select authorId, firstName, middleName, lastName, phoneNo from author_d where authorId =?";

    private static final String updateAuthrD = "update author_d set lastName = ? where authorId = ?;";

    private static final String deleteAuthrD = "delete from author_d where authorId = 3;";

    public static void main(String[] argv) throws SQLException {
        AuthrD createAuthorDTable = new AuthrD();
        createAuthorDTable.createTable();
        createAuthorDTable.insertRecord();
        createAuthorDTable.selectRecord();
        createAuthorDTable.updateRecord();
        createAuthorDTable.deleteRecord();
    }

    public void createTable() throws SQLException {
//
//        System.out.println(createTableSQL);
//        // Step 1: Establishing a Connection
        try (Connection connection = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/jdbc_lab", "root", "password");
             Statement statement = connection.createStatement();) {
            statement.execute(createTableSQL);
            System.out.println("Table Created Successfully");
            connection.close();
        } catch (SQLException e) {
            // print SQL exception information
            printSQLException(e);
        }

        // Step 4: try-with-resource statement will auto close the connection.
    }
    public void insertRecord() throws SQLException {
        System.out.println(insertAuthrD);
        // Step 1: Establishing a Connection
        try (Connection connection = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/jdbc_lab", "root", "password");
             // Step 2:Create a statement using connection object
             PreparedStatement preparedStatement = connection.prepareStatement(insertAuthrD)) {
            preparedStatement.setInt(1, 1);
            preparedStatement.setString(2, "Tony");
            preparedStatement.setString(3, "John");
            preparedStatement.setString(4, "Lambert");
            preparedStatement.setString(5, "220-123-4567");

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
            connection.close();
        } catch (SQLException e) {

            // print SQL exception information
            printSQLException(e);
        }

        // Step 4: try-with-resource statement will auto close the connection.
    }

    public void selectRecord() throws SQLException {
 try (Connection connection = DriverManager
         .getConnection("jdbc:mysql://localhost:3306/jdbc_lab", "root", "password");

    // Step 2:Create a statement using connection object
    PreparedStatement preparedStatement = connection.prepareStatement(queryAuthrD);) {
        preparedStatement.setInt(1, 1);
        System.out.println(preparedStatement);
        // Step 3: Execute the query or update query
        ResultSet rs = preparedStatement.executeQuery();

        // Step 4: Process the ResultSet object.
        while (rs.next()) {
            int authorId = rs.getInt("authorId");
            String firstName = rs.getString("firstName");
            String middleName = rs.getString("middleName");
            String lastName = rs.getString("lastName");
            String phoneNo = rs.getString("phoneNo");
            System.out.println(authorId + "," + firstName + "," + middleName + "," + lastName + "," + phoneNo);
        }
     connection.close();
    } catch (SQLException e) {
        printSQLException(e);
    }
    // Step 4: try-with-resource statement will auto close the connection.
}

    public void updateRecord() throws SQLException {
        System.out.println(updateAuthrD);
        // Step 1: Establishing a Connection
        try (Connection connection = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/jdbc_lab", "root", "password");

             // Step 2:Create a statement using connection object
             PreparedStatement preparedStatement = connection.prepareStatement(updateAuthrD)) {
            preparedStatement.setString(1, "Ram");
            preparedStatement.setInt(2, 1);

            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
            connection.close();
        } catch (SQLException e) {

            // print SQL exception information
            printSQLException(e);
        }

        // Step 4: try-with-resource statement will auto close the connection.
    }


    public void deleteRecord() throws SQLException {
        System.out.println(deleteAuthrD);

        // Step 1: Establishing a Connection
        try (Connection connection = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/jdbc_lab", "root", "password");

             // Step 2:Create a statement using connection object
             Statement statement = connection.createStatement();) {

            // Step 3: Execute the query or update query
            int result = statement.executeUpdate(deleteAuthrD);
            System.out.println("Number of records affected :: " + result);
            connection.close();
        } catch (SQLException e) {

            // print SQL exception information
            printSQLException(e);
        }

        // Step 4: try-with-resource statement will auto close the connection.
    }


    public static void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}

