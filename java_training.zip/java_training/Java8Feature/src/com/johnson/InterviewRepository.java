package com.johnson;

import java.util.ArrayList;
import java.util.List;

public class InterviewRepository {
    private static List<Candidate> candidateList;
    static {
        prepareCandidateList();
    }

    public static List<Candidate> getCandidateList() {
        return candidateList;
    }

    public static void setCandidateList(List<Candidate> candidateList) {
        InterviewRepository.candidateList = candidateList;
    }

    private static void prepareCandidateList(){
        candidateList = new ArrayList<>();
        candidateList.add(new Candidate("Ramesh", "java", "Austin", 5));
        candidateList.add(new Candidate("Justin", "C#", "Dallas", 4));
        candidateList.add(new Candidate("Nathan", "java", "San Antonio", 7));
        candidateList.add(new Candidate("Pamesh", "Python", "Austin", 0));
        candidateList.add(new Candidate("Radisson", "SQL", "Irving", 2));
        candidateList.add(new Candidate("Priya", "java", "Dallas", 10));
        candidateList.add(new Candidate("Henry", "C#", "Dallas", 4));
        candidateList.add(new Candidate("Nathan", "C#", "Allen", 0));
        candidateList.add(new Candidate("Jake", "Python", "Dallas", 15));
        candidateList.add(new Candidate("Radisson", "SQL", "Austin", 2));
        candidateList.add(new Candidate("Ramesh", "java", "Austin", 0));
        candidateList.add(new Candidate("Justice", "C#", "Dallas", 4));
        candidateList.add(new Candidate("Nathan", "java", "San Antonio", 7));
    }
}
