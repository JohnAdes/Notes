package com.johnson;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class BasicFunctionalInterface {

    public static void main(String[] args){
        Consumer<String> consumer = (String str)-> System.out.println(str);
            consumer.accept("Hi Everyone!");

        Supplier<String> supplier =()->"Welcome to Capgemini";
        consumer.accept(supplier.get());
        Predicate<Integer> predicate=num->num%2==0;
        System.out.println(predicate.test(38));
        System.out.println(predicate.test(65));
        BiFunction<Integer, Integer, Integer> maxFunction = (x, y)->x>y?x:y;
        System.out.println(maxFunction.apply(29, 18));
        BiFunction<Integer, Integer, Integer> maxFunction1 = (x, y)->x+y;
        System.out.println(maxFunction1.apply(29, 18));
        BiFunction<Integer, Integer, Integer> maxFunction2 = (x, y)->x-y;
        System.out.println(maxFunction2.apply(29, 18));
        BiFunction<Integer, Integer, Integer> maxFunction3 = (x, y)->x*y;
        System.out.println(maxFunction3.apply(29, 18));
        BiFunction<Double, Double, Double> maxFunction4 = (x, y)->x/y;
        System.out.println(maxFunction4.apply(29.0, 18.0));
        BiFunction<Integer, Integer, Integer> maxFunction5 = (x, y)->x%y;
        System.out.println(maxFunction5.apply(29, 18));
    }
}
