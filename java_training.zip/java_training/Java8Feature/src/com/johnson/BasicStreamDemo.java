package com.johnson;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BasicStreamDemo {
    public static void main(String[] args) {

        Stream<String> stream = Stream.of("C", "A", "P", "G", "E", "M", "I", "N", "I");
        stream.forEach((location) -> System.out.println(location));

        List<String> locations = Arrays.asList(new String[]{"New York", "California", "WashingtonDC", "Texas", "Chicago", "Bangalore", "Mumbai"});
        stream = locations.stream();
        List<String> results = locations.stream().filter((location) -> location.length() > 8).collect(Collectors.toList());
        results.stream().forEach(System.out::println);
    }
}