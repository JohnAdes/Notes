package com.johnson;

import java.util.*;
import java.util.stream.Collectors;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;



public class CandidateStreamingOperations {
    private static InterviewRepository InterviewRespository;

    public static void main(String[] args) {
//List Candidate Names from Pune City
        System.out.println("List Candidates Austin");
        List<Candidate> austinCandidates = InterviewRespository.getCandidateList().stream().filter((candidate) -> candidate.getCity().equals("Austin")).collect(Collectors.toList());
        austinCandidates.forEach(System.out::println);
        println();
//List City and Count of candidate per City
        System.out.println("Candidate Count per City");
        Map<String, List<Candidate>> cityCount = InterviewRespository.getCandidateList().stream().collect(Collectors.groupingBy((student) -> student.getCity()));
        for (String city : cityCount.keySet()) {
            System.out.println(city + ":" + cityCount.get(city).size());
        }
        println();
//list of technical Expretise and Count of Candidates
        System.out.println("Candidate count by technical Expertise");
        Map<String, List<Candidate>> techCount = InterviewRespository.getCandidateList().stream().collect(Collectors.groupingBy((student) -> student.getTechnicalExpertise()));
        for (String techSubject : techCount.keySet()) {
            System.out.println(techSubject + ":" + techCount.get(techSubject).size());
        }
        println();
//List Fresher Candidates
        System.out.println("Fresher Candidate List");
        List<Candidate> freshers = InterviewRespository.getCandidateList().stream().filter((candidate) -> candidate.getYearsOfExperience() == 0).collect(Collectors.toList());
        freshers.forEach(System.out::println);
        println();

        //listing candidates with highest experience
//first find out the highest years of experience value
        Integer maxYear = InterviewRepository.getCandidateList().stream().map((candidate) -> candidate.getYearsOfExperience()).max(Integer::compare).get();
        List<Candidate> seniors = InterviewRepository.getCandidateList().stream().filter((candidate) -> candidate.getYearsOfExperience() == maxYear).collect(Collectors.toList());
        System.out.println("Candidates having maximum experience");
        seniors.forEach(System.out::println);

//sort the candidates by their years of experience
//        printLine();
        System.out.println("Sorted List of Candidates by Experience");
//create a comparable lambda which we will use for sorting
        Comparator<Candidate> yearComparator = (cand1, cand2)->cand1.getYearsOfExperience()-cand2.getYearsOfExperience();
//pass the comparator in sorted() method of stream
        InterviewRepository.getCandidateList().stream().sorted(yearComparator).forEach(System.out::println);

//sort the candidates by city name
//        printLine();
        System.out.println("Sorted List of Candidates by City Name");
//create a comparable lambda which we will use for sorting
        Comparator<Candidate> cityComparator = (cand1,cand2)->cand1.getCity().compareTo(cand2.getCity());
//pass the comparator in sorted() method of stream
        InterviewRepository.getCandidateList().stream().sorted(cityComparator).forEach(System.out::println);
    }
    private static void println()
    {
        System.out.println("===============================================================================================");
    }
}