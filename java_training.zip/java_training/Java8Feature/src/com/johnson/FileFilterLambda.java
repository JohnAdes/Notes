package com.johnson;

import java.io.File;
import java.io.FileFilter;

public class FileFilterLambda {
    public static void main(String[] args) {
        File dir = new File("C:\\Users\\jadeshin\\Downloads");
        File[] contents = dir.listFiles();
        for (File file : contents) {
            System.out.println(file);
        }

        FileFilter filter = (File pathname) -> pathname.getName().endsWith(".pdf");
        File dir1 = new File("C:\\Users\\jadeshin\\Downloads");
        File[] contents1 = dir1.listFiles(filter);
        for (File file : contents1) {
            System.out.println("Selected Files: " +file);
        }
    }
}
