package com.johnson;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;public class ReduceDemo {
    public static void main(String[] args) {
        List<Integer> intList= Arrays.asList(7,9,13,11,-1);
        Optional<Integer>result=intList.stream().filter((a)->a>0).reduce((a, b)->a>b?a:b);
        if(result.isPresent())
        {
            System.out.println("Result"+result.get());
        }
        Optional<Integer> result1=intList.stream().filter((a)->a>0).reduce((a, b)->a+b);
        if(result1.isPresent())
        {
            System.out.println("Result"+result1.get());
        }
        Optional<Integer> result2=intList.stream().filter((a)->a>0).reduce((a, b)->a-b);
        if(result2.isPresent())
        {
            System.out.println("Result"+result2.get());
        }
        Optional<Integer> result3=intList.stream().filter((a)->a>0).reduce((a, b)->a*b);
        if(result3.isPresent())
        {
            System.out.println("Result"+result3.get());
        }
        Optional<Integer>result4=intList.stream().filter((a)->a>0).reduce((a, b)->a/b);
        if(result4.isPresent())
        {
            System.out.println("Result"+result4.get());
        }
    }
}

