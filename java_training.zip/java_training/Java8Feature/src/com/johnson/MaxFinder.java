package com.johnson;

@FunctionalInterface
public interface MaxFinder {
    int maximun(int num1,int num2);
}



class MaxFinderImpl implements MaxFinder
{
    public int maximun(int num1,int num2)
    {
        return num1>num2?num1:num2;
    }
}
class TestMain
{
    public static void main(String[] args) {
        MaxFinder finder=new MaxFinderImpl();
        int results=finder.maximun(89, 101);
        System.out.println(results);
    }
}

class TestMain1
{
    public static void main(String[] args) {
        MaxFinder finder=(num1,num2)->num1>num2?num1:num2;
        int results=finder.maximun(45, 82);
        System.out.println(results);
    }
}