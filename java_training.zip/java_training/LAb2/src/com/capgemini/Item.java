package com.capgemini;

abstract class Item {
    private int id;
    private String title;
    private int copies;

    public Item() {
    }
    abstract void checkIn();
    abstract void checkOut();
    abstract void addItem();

//
//        double billing()
//        {
//            double total=0.0;
//            total+=price*gst;
//            System.out.println("Billing Before Discount"+total);
//            return total;
//        }
    }
    abstract class WrittenItem extends Item
    {
        private String author;

        @Override
        void checkIn() {

        }

        @Override
        void checkOut() {

        }

        @Override
        void addItem() {

        }


    class Book extends WrittenItem
    {

    }
    class JournalPaper extends WrittenItem
    {
    private int yearPublished;

    }




}
