package com.johnson;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Report {

    private Date wkEnding;
    private Employee employee;
    private Client client;
    private List<Activity> activities;
    private String remarks;

    public Report(String date, String employeeName, String clientName, String manager, ArrayList<Activity> activities, String remark) {
    }

    public Report(Date wkEnding, Employee employee, Client client, List<Activity> activities, String remarks) {
        this.wkEnding = wkEnding;
        this.employee = employee;
        this.client = client;
        this.activities = activities;
        this.remarks = remarks;
    }

    public Report() {

    }

    public Date getWkEnding() {
        return wkEnding;
    }

    public void setWkEnding(Date wkEnding) {
        this.wkEnding = this.wkEnding;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public List<Activity> getActivities() {
        return activities;
    }

    public void setActivities(List<Activity> activities) {
        this.activities = activities;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setActivities() {
    }
}

