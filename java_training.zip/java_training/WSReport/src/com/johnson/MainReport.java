package com.johnson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainReport {


    public static void main(String[] args) throws IOException {
        Report report = new Report();
        listReports(report);
        displayReports(report);
    }

    private static void listReports(Report report) {
//        int numOfReport = 0;
//        Scanner inp = new Scanner(System.in);
//        System.out.println("Enter number of reports: ");
//        numOfReport = inp.nextInt();
        ArrayList<Report> wsr = new ArrayList<>();
        for(Report reports : wsr){

            try
            {
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                System.out.println("Enter week ending(mm/dd/yyyy): ");
                String date = br.readLine();
                Date wkEnding = new SimpleDateFormat("mm/dd/yyyy").parse(date);
                report.setWkEnding(wkEnding);

                Employee employee = new Employee();
                System.out.println("Enter Employee name: ");
                String employeeName = br.readLine();
                report.getEmployee().setEmployeeName(employeeName);

                Client client=new Client();
                System.out.println("Enter the client's name: ");
                String clientName=br.readLine();
               report.getClient().setClientName(clientName);
                System.out.println("Enter the client's manager: ");
                String manager=br.readLine();
                report.getClient().setManager(manager);
                ArrayList<Activity> activities = new ArrayList<>();
                for (Activity act: activities ) {
                    System.out.println("Enter your activity: ");
                    String activity =br.readLine();
                    report.setActivities();
                }
                System.out.println("Enter the Remarks");
                String remark=br.readLine();
                report.setRemarks(remark);

                wsr.add(new Report(date, employeeName,clientName, manager,activities, remark));

            }catch(IOException | ParseException e)
            {
            }

        }

    }

    private static void displayReports(Report report){
        System.out.println("Week Ending |   Resource Name   |  client   |  Client Manager  |  Activity   |   Remarks   ");
        System.out.print (report.getWkEnding());
        System.out.printf( "%s", report.getEmployee().getEmployeeName());
        System.out.printf( "%s",report.getClient().getClientName());
        System.out.printf( "%s", report.getClient().getManager());
        System.out.printf("%s", report.getActivities().iterator());
    }
}