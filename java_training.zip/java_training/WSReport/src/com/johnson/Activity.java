package com.johnson;

public class Activity {

    private String description;

}
