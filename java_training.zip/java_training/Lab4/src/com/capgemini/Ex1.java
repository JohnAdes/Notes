package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ex1 {
    static int sum = 0;

    public static int sumOfDigitCube(int n){
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter the number to Check");
            n = Integer.parseInt(br.readLine());
            while(n>0) {
                int mod = n%10;
                sum = sum + (int) Math.pow(mod, 3);
                n = n/10;
            } System.out.println("The sum of Digit Cube = "+ sum );
        } catch (IOException e) {

        }
        return sum;
    }
    public static void main(String[] args){
        sumOfDigitCube(args.length);
    }

}
