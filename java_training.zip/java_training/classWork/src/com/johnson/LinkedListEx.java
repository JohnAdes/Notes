package com.johnson;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

public class LinkedListEx {
    public static void main(String[] args) {
        LinkedList<String> c=new LinkedList<>();
        c.add("Eleanor Kelman");
        c.add("Christopher");
        c.add("Lakshmi");
        c.add("Jennifer");
        c.add("Chadwick");
        c.add("Gayathri");
        c.add("Niteesh");
        c.add("Jayasurya");
        c.add("Chadwick");
        c.add("Joel Roshan");
        System.out.println("Collection"+c);
        LinkedList<String> l=new LinkedList<>();
        l.addAll(c);
        System.out.println(" New Collection"+l);

        l.add(3, "Hemanth");
        System.out.println(" New Collection"+l);
        l.set(2, "Camilo");
        System.out.println(" New Collection"+l);
        l.remove("Joel Roshan") ;
        System.out.println(" New Collection"+l);
        l.remove(4);
        System.out.println(" New Collection"+l);
        System.out.println("Size"+l.size());
        System.out.println("Contains"+l.contains("Chadwick"));
        System.out.println("Empty"+l.isEmpty());
        System.out.println("Get"+l.get(6));
        l.addFirst("Nathan");
        l.addLast("Linny");
        System.out.println("LInkedList Container"+l);
        l.peek();
        System.out.println("LInkedList Container"+l);
        l.poll();
        System.out.println("LInkedList Container"+l);

        Collections.sort(l);
        System.out.println("sorted linkedList: " + l);
    }


}
