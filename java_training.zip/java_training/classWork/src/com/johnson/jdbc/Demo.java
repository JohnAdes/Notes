package com.johnson.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {
    public static void main(String[] args) {
        Connection con=null;
        Statement stmt=null;
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded Successfully");
        }catch(ClassNotFoundException e)
        {
            System.out.println("Driver not Loaded Successfully");
        }
        try
        {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Java_training", "root", "password");
            System.out.println("Connection Eastablished Successfully");
            stmt=con.createStatement();
//String cs="CREATE TABLE EMP(empId int,empName varchar(20),empSal int)";
//stmt.execute(cs);
            String cs="INSERT INTO EMP VALUES(1001,'Eleanor Kelman',30000)";
            stmt.executeUpdate(cs);
            cs="INSERT INTO EMP VALUES(1002,'Chadwick',35000)";
            stmt.executeUpdate(cs);
            cs="INSERT INTO EMP VALUES(1003,'Christopher',40000)";
            stmt.executeUpdate(cs);

            stmt.close();
        }catch(SQLException e)
        {
            System.out.println("Connection not eastablished");
        }
        finally
        {
            try {
                con.close();
            } catch (SQLException e) {
// TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    }
}