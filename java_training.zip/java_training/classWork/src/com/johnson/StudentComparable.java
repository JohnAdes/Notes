package com.johnson;

import java.util.Set;
import java.util.TreeSet;

class StudentComparapble implements Comparable<Student>
{
    private String name;
    private long id;
    private double gpa;
    public StudentComparapble(String name, long id, double gpa) {
        super();
        this.name = name;
        this.id = id;
        this.gpa = gpa;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public double getGpa() {
        return gpa;
    }
    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    @Override
    public String toString() {
        return "Student [name=" + name + ", id=" + id + ", gpa=" + gpa + "]";
    }
    @Override
    public int compareTo(Student o) {
        int result=this.name.compareTo(o.getName());
        if(result>0)
        {
            return 1;
        }else if(result<0)
        {
            return -1;
        }
        else
            return 0;
    }
}

class StudentComparator1
{
    public static void main(String[] args) {
        Set<Student> studentList=new TreeSet<>();


        studentList.add(new Student("Eleanor Kelman",12, 8.7));
        studentList.add(new Student("Christopher",13, 8.8));
        studentList.add(new Student("Lakshmi",14, 9.7));
        studentList.add(new Student("Chadwick",16, 6.7));
        studentList.add(new Student("Jayasurya",18, 5.7));

        System.out.println("Student Names printing in Ascending Order");
        for(Student student:studentList)
        {
            System.out.println(student);
        }
    }
}