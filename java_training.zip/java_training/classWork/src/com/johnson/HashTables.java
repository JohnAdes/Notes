package com.johnson;

import java.util.Enumeration;
import java.util.Hashtable;

public class HashTables {

    public static void main(String[] args) {
        Hashtable<String,Double> hm=new Hashtable<String,Double>();
        hm.put("Eleanor Kelman", new Double(5000));
        hm.put("Christopher",new Double(6000));
        hm.put("Lakshmi", new Double(7000));
        hm.put("Jennifer", new Double(8000));
        hm.put("Chadwick", new Double(9000));
        hm.put("Gayathri", new Double(4000));
        hm.put("Niteesh", new Double(8900));
        hm.put("Jayasurya", new Double(10000));
        hm.put("Jayasurya", new Double(8000));
        hm.put("Joel Roshan", new Double(7600));
        hm.put(null, new Double(7600));
        System.out.println("Map "+hm);
//Show all balances in hashtable
        Enumeration<String> names=hm.keys();
        while(names.hasMoreElements())
        {
            String str=names.nextElement();
            System.out.println(str+" "+hm.get(str));
        }
//deposite 4k into Christopher Account
        double balance=hm.get("Christopher");
        hm.put("Christopher", balance+4000);
        System.out.println("Christopher New Balance"+hm.get("Christopher"));
    }
}
