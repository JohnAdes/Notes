package com.johnson;

import java.util.ArrayList;

public class ArrayListEx {


        private int employeeId;
        private String employeeName;

        public ArrayListEx(int employeeId, String employeeName) {
            this.employeeId = employeeId;
            this.employeeName = employeeName;
        }
        @Override
        public String toString() {
            return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + "]";
        }



    }
    class Manager extends ArrayListEx
    {
        private String designation;



        public Manager(int employeeId, String employeeName, String designation) {
            super(employeeId, employeeName);
            this.designation = designation;
        }



        @Override
        public String toString() {
            return super.toString()+"Manager [designation=" + designation + "]";
        }



    }
    class Driver extends ArrayListEx
    {
        private double salary;



        public Driver(int employeeId, String employeeName, double salary) {
            super(employeeId, employeeName);
            this.salary = salary;
        }



        @Override
        public String toString() {
            return super.toString()+"Driver [salary=" + salary + "]";
        }



    }
    class TestEmployee
    {
        public static void main(String[] args) {
            ArrayListEx m=new Manager(121,"Shailesh","SM");
            ArrayListEx d=new Driver(123,"Jacob",30000);

            ArrayList<ArrayListEx> al=new ArrayList<ArrayListEx>();
            al.add(m);
            al.add(d);
            System.out.println(al);
// al.add(d);
        }
}
