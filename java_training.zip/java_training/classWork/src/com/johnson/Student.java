package com.johnson;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Student {
    private String name;
    private long id;
    private double gpa;
    public Student(String name, long id, double gpa) {
        super();
        this.name = name;
        this.id = id;
        this.gpa = gpa;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public double getGpa() {
        return gpa;
    }
    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    @Override
    public String toString() {
        return "Student [name=" + name + ", id=" + id + ", gpa=" + gpa + "]";
    }
}


class StudentSortGPA implements Comparator<Student>
{
    @Override
    public int compare(Student o1, Student o2) {
        if(o1.getGpa()<o2.getGpa())
        {
            return 1;
        }else if(o1.getGpa()>o2.getGpa())
        {
            return -1;
        }else
        {
            return 0;
        }
    }
}
class StudentSortName implements Comparator<Student>
{
    @Override
    public int compare(Student o1, Student o2) {
        int results=o1.getName().compareTo(o2.getName());
        if(results!=0)
        {
            return results;
        }else
        {
            return 0;
        }
    }
}
class StudentComparator {
    public static void main(String[] args) {
        List<Student> studentList = new ArrayList<>();
        Comparator<Student> sortName = new StudentSortName();
        Comparator<Student> sortGPA = new StudentSortGPA();

        studentList.add(new Student("Eleanor Kelman", 12, 8.7));
        studentList.add(new Student("Christopher", 13, 8.8));
        studentList.add(new Student("Lakshmi", 14, 9.7));
        studentList.add(new Student("Chadwick", 16, 6.7));
        studentList.add(new Student("Jayasurya", 18, 5.7));
        Collections.sort(studentList, sortName);
        System.out.println("Student Names printing in Ascending Order");
        for (Student student : studentList) {
            System.out.println(student);
        }
        Collections.sort(studentList, sortGPA);
        System.out.println("Student GPA printing in Ascending Order");
        for (Student student : studentList) {
            System.out.println(student);
        }

    }
}