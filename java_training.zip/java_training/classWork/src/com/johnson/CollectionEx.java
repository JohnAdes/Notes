package com.johnson;

import java.util.*;

public class CollectionEx {

    public static void main(String[] args) {
        Collection c=new ArrayList();
        c.add("Eleanor Kelman");
        c.add("Christopher");
        c.add("Lakshmi");
        c.add("Jennifer");
        c.add("Chadwick");
        c.add("Gayathri");
        c.add("Niteesh");
        c.add("Jayasurya");
        c.add("Chadwick");
        c.add("Joel Roshan");
        System.out.println("Collection"+c);
        Collection c1=new ArrayList();
        c1.addAll(c);
        System.out.println(" New Collection"+c1);
        List l=(List)c1;
        l.add(3, "Hemanth");
        System.out.println(" New Collection"+l);
        l.set(2, "Camilo");
        System.out.println(" New Collection"+l);
        l.remove("Joel Roshan") ;
        System.out.println(" New Collection"+l);
        l.remove(4);
        System.out.println(" New Collection"+l);
        System.out.println("Size"+l.size());
        System.out.println("Contains"+l.contains("Chadwick"));
        System.out.println("Empty"+l.isEmpty());
        System.out.println("Get"+l.get(6));
        ListIterator it=l.listIterator();
        System.out.println("Printing the elements in Forward Direction");
        while(it.hasNext())
        {
            System.out.println("Welcome to Java Evening Session =======> "+it.next());
        }
        System.out.println("Printing the elements in reverese Direction");
        while(it.hasPrevious())
        {
            System.out.println("Welcome to Java Evening Session =======> "+it.previous());
        }

        Collections.sort(l);
        System.out.println("Updated List"+l);
    }
}
