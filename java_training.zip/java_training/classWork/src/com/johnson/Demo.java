package com.johnson;

class Demo
{
    private int a=10;
    //accessors
    public int getA()
    {
        return a;
    }
    //mutators
    public void setA(int a)
    {
        this.a=a;
    }
    void display()
    {
        System.out.println("Display Method "+a);
    }
    public static void main(String[] args) {
        Demo d=new Demo();
        d.setA(89);
        System.out.println(d.getA());
    }
}
class Test
{
    public static void main(String[] args) {
        Demo d=new Demo();
        d.setA(89);
        System.out.println(d.getA());
    }
}

class Account
{
    private double balance; public double getBalance() {
    return balance;
} public void setBalance(double balance) {
    this.balance = balance;
    System.out.println("Initial Balance is"+balance);
}
    public void deposite(double amount)
    {
        balance+=amount;
        System.out.println("Deposited Balance"+this.balance);
    }
    public void withdraw(double amount)
    {
        if(balance>amount)
        {
            balance-=amount;
            System.out.println("WithDrawn Amount"+balance);
        }else
        {
            System.out.println("Balance"+balance);
        }
    }
}
class TestAccount
{
    public static void main(String[] args) {
        Account account=new Account();
        account.setBalance(10000.00);
        account.deposite(25000.00);
        account.withdraw(32000.00);
        System.out.println("Final Balance"+account.getBalance());
    }
}

