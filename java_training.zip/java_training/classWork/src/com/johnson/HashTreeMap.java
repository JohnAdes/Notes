package com.johnson;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class HashTreeMap {

    public static void main(String[] args) {
        TreeMap<String,Double> hm=new TreeMap<String,Double>();
        hm.put("Eleanor Kelman", new Double(5000));
        hm.put("Christopher",new Double(6000));
        hm.put("Lakshmi", new Double(7000));
        hm.put("Jennifer", new Double(8000));
        hm.put("Chadwick", new Double(9000));
        hm.put("Gayathri", new Double(4000));
        hm.put("Niteesh", new Double(8900));
        hm.put("Jayasurya", new Double(10000));
        hm.put("Jayasurya", new Double(8000));
        hm.put("Joel Roshan", new Double(7600));
        hm.put(null, new Double(7600));
        System.out.println("Map "+hm);
//Get a set of entries
        Set<Map.Entry<String,Double>> set=hm.entrySet();
//Display the set
        for(Map.Entry<String,Double> me:set)
        {
            System.out.println(me.getKey()+":");
            System.out.println(me.getValue());
        }
        System.out.println();
//deposite 4k into Christopher Account
        double balance=hm.get("Christopher");
        hm.put("Christopher", balance+4000);
        System.out.println("Christopher New Balance"+hm.get("Christopher"));
    }
}
