package com.johnson;

public class Person {

        String firstName,LastName;



        public Person(String firstName, String lastName) {
            super();
            this.firstName = firstName;
            LastName = lastName;
        }
        public String toString()
        {
            return firstName+" "+LastName;
        }
        public static void main(String[] args) {
            Person p=new Person("Naveen","Kumar");
            System.out.println(p);
        }
}
