package com.capgemini.training;

public class Employee {
	private Address address;
	private Integer employeeId;
	private Double salary;
	private String employeeName;
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		System.out.println("From Setter of Employee Address ");
		this.address = address;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void display()
	{
		System.out.println("\n Employee Details");
		System.out.println("Employee Id: "+this.getEmployeeId());
		System.out.println("Employee Name: "+this.getEmployeeName());
		System.out.println("Employee Salary: "+this.getSalary());
		System.out.println("Employee Address Line1"+this.getAddress().getAddressLine1());
		System.out.println("Employee Address Line2"+this.getAddress().getAddressLine2());

	}

}
