package com.capgemini.training.resources;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.training.Address;
import com.capgemini.training.Employee;

/*<bean id="empObject" class="com.capgemini.training.Employee" scope="singleton">
		<property name="employeeId" value="1001" />
		<property name="employeeName" value="Eleanor Kelman" />
		<property name="salary" value="30000" />
		<property name="address" ref="addressObject" />
	</bean>
	<bean id="addressObject" class="com.capgemini.training.Address" scope="singleton">
		<property name="addressLine1" value="New York" />
		<property name="addressLine2" value="US" />
	</bean>
 * 
 */
@Configuration
public class MyConfiguration {
    @Bean(name="employeeSp")
	public Employee createEmployee()
	{
		Employee employee=new Employee();
		employee.setEmployeeId(1003);
		employee.setEmployeeName("Naveen Kumar");
		employee.setSalary(30000.00);
		Address address=createAddress();
		employee.setAddress(address);
		return employee;
	}
    @Bean(name="address")
    public Address createAddress()
    {
    	Address address=new Address();
    	address.setAddressLine1("RRNagar Bangalore");
    	address.setAddressLine2("Karnataka India ");
    	return address;
    }
}
