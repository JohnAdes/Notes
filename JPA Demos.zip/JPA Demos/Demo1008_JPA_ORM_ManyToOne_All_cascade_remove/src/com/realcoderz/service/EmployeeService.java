package com.realcoderz.service;

import com.realcoderz.businessbean.DepartmentBean;
import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeService {
	public Integer insertEmployeeAndDepartment(EmployeeBean employee1, EmployeeBean employee2, DepartmentBean d) throws Exception;
	public void removeEmployeeAndDepartment(EmployeeBean employee) throws Exception;
	
}
