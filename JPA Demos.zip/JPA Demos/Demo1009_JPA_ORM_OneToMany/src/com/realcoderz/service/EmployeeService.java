package com.realcoderz.service;

import com.realcoderz.businessbean.CompanyBean;
import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeService {
	public Integer createCompanyAndEmployeeRecords(CompanyBean companyBean1,EmployeeBean employeeBean1,EmployeeBean employeeBean2) throws Exception ;
	void deleteCompanyAndEmployeeRecords(CompanyBean companyBean)
			throws Exception;
}
