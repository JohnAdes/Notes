package com.realcoderz.service;

import com.realcoderz.businessbean.CompanyBean;
import com.realcoderz.businessbean.EmployeeBean;
import com.realcoderz.dao.EmployeeDAO;
import com.realcoderz.utility.Factory;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public Integer createCompanyAndEmployeeRecords(CompanyBean companyBean1,EmployeeBean employeeBean1,EmployeeBean employeeBean2) throws Exception {
		int employeeId = 0;
		EmployeeDAO employeeDAO = Factory.createEmployeeDAO();
		try {
			employeeId = employeeDAO.createCompanyAndEmployeeRecords(companyBean1,employeeBean1,employeeBean2);
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw e;
		}
		return employeeId;
	}

	@Override
	public void deleteCompanyAndEmployeeRecords(CompanyBean companyBean)
			throws Exception {
		EmployeeDAO employeeDAO = Factory.createEmployeeDAO();
		try {
			 employeeDAO.deleteCompanyAndEmployeeRecords(companyBean);
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw e;
		}
	}
}
