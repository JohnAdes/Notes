package com.realcoderz.dao;

import com.realcoderz.businessbean.CompanyBean;
import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeDAO {
	
	public Integer createCompanyAndEmployeeRecords(CompanyBean companyBean1,EmployeeBean employeeBean1,EmployeeBean employeeBean2) throws Exception ;

	public void deleteCompanyAndEmployeeRecords(CompanyBean companyBean) throws Exception;
	
}
