package com.realcoderz.ui;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.realcoderz.entity.EmployeeEntity;

public class UITester_1_persist {
	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("unit1");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EmployeeEntity employee = new EmployeeEntity();
		employee.setEmployeeName("HariKrishna");
		employee.setRole("Analyst");
		employee.setSalary(200000.0);
		employee.setInsertTime(new Date());
		
		entityManager.getTransaction().begin();
		entityManager.persist(employee);
		entityManager.getTransaction().commit();
		System.out.println("Employee registered successfully!!"+employee.getEmployeeId());
		
		entityManager.close();
		entityManagerFactory.close();
	}
	
}
