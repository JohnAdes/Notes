package com.realcoderz.dao;

public interface EmployeeDAO {
	
	public void retrieveEmployeeDetails() throws Exception;
	public void retrieveEmployeeDetailsUsingHibernateProvider() throws Exception;
}
