package com.realcoderz.service;

import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeService {
	Integer addEmployeeTest1(EmployeeBean employee) throws Exception;
	Integer addEmployeeTest2(EmployeeBean employee) throws Exception;
	Integer addEmployeeTest3(EmployeeBean employee) throws Exception;

}
