package com.realcoderz.dao;

import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeDAO {
	
	Integer addEmployeeTest1(EmployeeBean employee) throws Exception;
	Integer addEmployeeTest2(EmployeeBean employee) throws Exception;
	Integer addEmployeeTest3(EmployeeBean employee) throws Exception;
	
}
