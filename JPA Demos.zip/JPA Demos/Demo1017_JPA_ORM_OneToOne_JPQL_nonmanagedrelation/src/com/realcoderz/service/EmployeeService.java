package com.realcoderz.service;

import com.realcoderz.businessbean.AssetBean;
import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeService {
	public void getAllEmployeesWithAssetDetails() throws Exception;

}
