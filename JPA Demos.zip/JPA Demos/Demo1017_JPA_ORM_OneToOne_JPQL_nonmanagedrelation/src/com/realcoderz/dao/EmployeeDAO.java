package com.realcoderz.dao;


public interface EmployeeDAO {
	public void getAllEmployeesWithAssetDetails() throws Exception;

}
