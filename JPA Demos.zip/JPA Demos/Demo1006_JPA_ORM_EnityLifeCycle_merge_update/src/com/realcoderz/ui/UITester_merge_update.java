package com.realcoderz.ui;

import com.realcoderz.businessbean.EmployeeBean;
import com.realcoderz.service.EmployeeService;
import com.realcoderz.utility.Factory;
import com.realcoderz.utility.JPAUtility;

public class UITester_merge_update {

	public static void main(String[] args) {
		try {
			addEmployee();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			JPAUtility.closeEntityManagerFactory();
		}

	}

	static public void addEmployee() {
		int id = 0;
		EmployeeBean bean = new EmployeeBean();
		bean.setEmployeeId(1002);
		bean.setEmployeeName("updatedname");
		bean.setSalary(400000.0);
		EmployeeService employeeService = Factory.createEmployeeService();
		try {
			id = employeeService.addEmployee(bean);
			System.out.println("Employee Updated Successfully: " + id);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
