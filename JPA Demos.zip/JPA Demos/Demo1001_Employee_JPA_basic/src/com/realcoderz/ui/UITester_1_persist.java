package com.realcoderz.ui;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.realcoderz.entity.EmployeeEntity;

public class UITester_1_persist {
	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("unit1");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//Transient State
		EmployeeEntity employee = new EmployeeEntity();
		employee.setEmployeeId(1001);
		employee.setEmployeeName("Ananth");
		employee.setRole("Analyst");
		employee.setSalary(200000.0);
		employee.setInsertTime(new Date());
	//Managed State	
		entityManager.getTransaction().begin();
		entityManager.persist(employee);
		entityManager.getTransaction().commit();
		
		employee.setRole("");
		
		
		System.out.println("Employee registered successfully!!");
		
		entityManager.close();
		entityManagerFactory.close();
	}
	
}
