package com.realcoderz.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.realcoderz.entity.EmployeeEntity;

public class UITester_4_remove {
	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("unit1");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
//Managed State
		EmployeeEntity employeeEntity = entityManager.find(EmployeeEntity.class, 1001);
		if(employeeEntity != null) {
			
			
		entityManager.getTransaction().begin();
		//Removed State 
		entityManager.remove(employeeEntity);
		entityManager.getTransaction().commit();
		System.out.println("Employee deleted successfully!!");
		} else {
			System.out.println("Please give a valid ID!!");	
		}
		entityManager.close();
		entityManagerFactory.close();
	}

}
