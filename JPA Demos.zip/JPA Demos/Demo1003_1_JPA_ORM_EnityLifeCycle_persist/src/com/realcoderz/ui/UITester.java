package com.realcoderz.ui;

import java.util.Date;

import com.realcoderz.businessbean.EmployeeBean;
import com.realcoderz.service.EmployeeService;
import com.realcoderz.utility.Factory;
import com.realcoderz.utility.JPAUtility;

public class UITester {

	public static void main(String[] args) {
		try {
			addEmployee();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			JPAUtility.closeEntityManagerFactory();
		}

	}

	static public void addEmployee() {
		int id = 0;
		EmployeeBean bean = new EmployeeBean();
		bean.setInsertTime(new Date());
		bean.setEmployeeName("MSD2");
		bean.setRole("Analyst");
		bean.setSalary(100000.0);
		EmployeeService employeeService = Factory.createEmployeeService();
		try {
			id = employeeService.addEmployee(bean);
			System.out.println("Employee Registered Successfully: " + id);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
