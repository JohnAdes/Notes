package com.realcoderz.dao;

import java.util.List;

import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeDAO {
	public List<EmployeeBean> retrieveEmployeeDetails() throws Exception;
	public List<EmployeeBean> retrieveEmployeeDetailsUsingHibernateProvider() throws Exception;
}
