package com.realcoderz.dao;

import com.realcoderz.businessbean.AssetBean;
import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeDAO {
	
	public void removeEmployeeAndAsset(EmployeeBean employee) throws Exception;
	 public Integer insertAssetWithEmployee(EmployeeBean employeeBean, AssetBean assetBean) throws Exception;
}
