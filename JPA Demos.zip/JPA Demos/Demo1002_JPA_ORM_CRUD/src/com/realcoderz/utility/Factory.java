package com.realcoderz.utility;

import com.realcoderz.dao.EmployeeDAO;
import com.realcoderz.dao.EmployeeDAOIMPL;
import com.realcoderz.service.EmployeeService;
import com.realcoderz.service.EmployeeServiceImpl;

public class Factory {
	
	public static EmployeeDAO createEmployeeDAO(){
		return new EmployeeDAOIMPL();
	}
	
	public static EmployeeService createEmployeeService(){
		return new EmployeeServiceImpl();
	}

}
