package com.accenture.lkm.utility;

import com.accenture.lkm.service.EmployeeService;
import com.accenture.lkm.service.EmployeeServiceImpl;
import com.realcoderz.dao.EmployeeDAO;
import com.realcoderz.dao.EmployeeDAOIMPL;

public class Factory {
	
	public static EmployeeDAO createEmployeeDAO(){
		return new EmployeeDAOIMPL();
	}
	
	public static EmployeeService createEmployeeService(){
		return new EmployeeServiceImpl();
	}

}
