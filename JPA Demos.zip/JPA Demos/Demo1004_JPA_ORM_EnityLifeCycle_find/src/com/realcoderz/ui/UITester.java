package com.realcoderz.ui;

import com.realcoderz.businessbean.EmployeeBean;
import com.realcoderz.service.EmployeeService;
import com.realcoderz.utility.Factory;
import com.realcoderz.utility.JPAUtility;

public class UITester {

	public static void main(String[] args) {
		try {
			findEmployeeById();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			JPAUtility.closeEntityManagerFactory();
		}

	}

	static public void findEmployeeById() {
		int employeeId = 0;
		EmployeeBean employee = null;
		EmployeeService employeeService = Factory.createEmployeeService();
		try {
			employee = employeeService.findEmployeeById(1002);
			employeeId = employee.getEmployeeId(); 
			System.out.println(employeeId+", "+employee.getEmployeeName());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}
