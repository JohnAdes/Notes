package com.realcoderz.service;

import com.realcoderz.businessbean.EmployeeBean;
import com.realcoderz.dao.EmployeeDAO;
import com.realcoderz.utility.Factory;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public EmployeeBean findEmployeeById(int employeeId) throws Exception {
		EmployeeBean employeeBean = null;
		try {
		EmployeeDAO employeeDAO = Factory.createEmployeeDAO();
		employeeBean=employeeDAO.findEmployeeById(employeeId);
		}catch (Exception exception) {
			throw exception;
		}
		return employeeBean;
	}



}
