package com.realcoderz.service;

import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeService {
	EmployeeBean findEmployeeById(int employeeId) throws Exception;

}
