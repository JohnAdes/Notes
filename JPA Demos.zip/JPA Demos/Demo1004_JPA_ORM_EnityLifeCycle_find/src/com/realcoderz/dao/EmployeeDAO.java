package com.realcoderz.dao;

import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeDAO {
	
	EmployeeBean findEmployeeById(int employeeId) throws Exception;
	
}
