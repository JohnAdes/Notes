package com.realcoderz.service;

import com.realcoderz.businessbean.AssetBean;
import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeService {
	public Integer insertAssetWithEmployee(EmployeeBean employeeBean, AssetBean assetBean) throws Exception;

}
