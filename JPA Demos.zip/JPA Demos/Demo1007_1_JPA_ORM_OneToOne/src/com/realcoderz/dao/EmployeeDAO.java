package com.realcoderz.dao;

import com.realcoderz.businessbean.AssetBean;
import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeDAO {
	
	 public Integer insertAssetWithEmployee(EmployeeBean employeeBean, AssetBean assetBean) throws Exception;
	
}
