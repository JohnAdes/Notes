package com.realcoderz.ui;

import java.util.List;

import com.realcoderz.businessbean.EmployeeBean;
import com.realcoderz.service.EmployeeService;
import com.realcoderz.utility.Factory;
import com.realcoderz.utility.JPAUtility;

public class UITester {

	public static void main(String[] args) {
		try {
			retrieveEmployeeNames();
			
			retrieveEmployeeIdAndNameDetails();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			JPAUtility.closeEntityManagerFactory();
		}

	}

	static public void retrieveEmployeeNames() {
		List<String> employees = null;
		
		EmployeeService employeeService = Factory.createEmployeeService();
		try {
			employees = employeeService.retrieveEmployeeNames();
			for(String e: employees) {
				System.out.println(e);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	static public void retrieveEmployeeIdAndNameDetails() {
		List<EmployeeBean> employees = null;
		
		EmployeeService employeeService = Factory.createEmployeeService();
		try {
			employees = employeeService.retrieveEmployeeIdAndNameColumns();
			
			for(EmployeeBean e: employees) {
				System.out.println(e.getEmployeeId()+","+e.getEmployeeName());
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
