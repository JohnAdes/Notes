package com.realcoderz.dao;

public interface EmployeeDAO {
	
	public void removeEmployeeById(int id) throws Exception;
	
}
