package com.realcoderz.service;

import com.realcoderz.businessbean.EmployeeBean;

public interface EmployeeService {
	Integer addEmployee(EmployeeBean employee) throws Exception;
	EmployeeBean getEmployeeDetails(int employeeId, int deptId);

}
