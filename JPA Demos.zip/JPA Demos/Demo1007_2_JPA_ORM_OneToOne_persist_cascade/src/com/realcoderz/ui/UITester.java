package com.realcoderz.ui;

import java.util.Date;

import com.realcoderz.businessbean.AssetBean;
import com.realcoderz.businessbean.EmployeeBean;
import com.realcoderz.service.EmployeeService;
import com.realcoderz.utility.Factory;
import com.realcoderz.utility.JPAUtility;

public class UITester {

	public static void main(String[] args) {
		try {
			insertAssetWithEmployee();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			JPAUtility.closeEntityManagerFactory();
		}

	}

	static void insertAssetWithEmployee() {
		int employeeId = 0;
		try {
			EmployeeService service = Factory.createEmployeeService();
			EmployeeBean employee = new EmployeeBean();
			employee.setEmployeeName("Rohit");
			employee.setInsertTime(new Date());
			employee.setRole("Sr.Analyst");
			employee.setSalary(200000.00);

			AssetBean asset = new AssetBean();
			asset.setAssetName("Laptop");
			asset.setAssetBrandName("Dell");
			asset.setValidityYears(3);

			employeeId = service.insertAssetWithEmployee(employee, asset);
			System.out.println("Employee inserted successfully!!" + employeeId);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
